import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User as FirebaseUser,
  onAuthStateChanged,
  signInWithPopup,
  signOut as firebaseSignOut,
  signInAnonymously,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  setDoc,
  onSnapshot,
  updateDoc,
} from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../firebase';
import { UserProfile } from '../types/auction';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  isAdmin: boolean;
  loading: boolean;
  loginWithGoogle: () => Promise<void>;
  loginAsGuest: (name: string, phone: string) => Promise<void>;
  logout: () => Promise<void>;
  updateBalance: (newBalance: number) => Promise<void>;
}

const ADMIN_EMAILS = ['mameboss98@gmail.com'];

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const isAdmin = currentUser?.email ? ADMIN_EMAILS.includes(currentUser.email.toLowerCase()) : false;

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setCurrentUser(firebaseUser);
      if (firebaseUser) {
        const userRef = doc(db, 'users', firebaseUser.uid);
        try {
          const userSnap = await getDoc(userRef);
          if (userSnap.exists()) {
            const data = userSnap.data();
            setUserProfile({
              id: firebaseUser.uid,
              name: data.displayName || firebaseUser.displayName || 'Addis Bidder',
              email: data.email || firebaseUser.email || '',
              phone: data.phoneNumber || '+251 911 000 000',
              walletBalanceETB: typeof data.balance === 'number' ? data.balance : 0,
              totalBidsPlaced: data.totalBidsPlaced || 0,
              winsCount: data.winsCount || 0,
              avatar: firebaseUser.photoURL || undefined,
            });
          } else {
            // New user: starts with 0 ETB balance
            const initialProfile: UserProfile = {
              id: firebaseUser.uid,
              name: firebaseUser.displayName || 'New Bidder',
              email: firebaseUser.email || '',
              phone: '+251 911 000 000',
              walletBalanceETB: 0,
              totalBidsPlaced: 0,
              winsCount: 0,
              avatar: firebaseUser.photoURL || undefined,
            };

            await setDoc(userRef, {
              id: firebaseUser.uid,
              email: firebaseUser.email || 'user@addisbid.et',
              displayName: initialProfile.name,
              phoneNumber: initialProfile.phone,
              balance: 0,
              role: ADMIN_EMAILS.includes(firebaseUser.email?.toLowerCase() || '') ? 'admin' : 'user',
              createdAt: new Date().toISOString(),
              totalBidsPlaced: 0,
              winsCount: 0,
            });

            setUserProfile(initialProfile);
          }

          // Real-time listener for balance updates (e.g. when Admin approves deposit)
          const unsubProfile = onSnapshot(userRef, (docSnap) => {
            if (docSnap.exists()) {
              const d = docSnap.data();
              setUserProfile((prev) =>
                prev
                  ? {
                      ...prev,
                      name: d.displayName || prev.name,
                      walletBalanceETB: typeof d.balance === 'number' ? d.balance : prev.walletBalanceETB,
                      totalBidsPlaced: d.totalBidsPlaced ?? prev.totalBidsPlaced,
                      winsCount: d.winsCount ?? prev.winsCount,
                    }
                  : null
              );
            }
          });

          return () => unsubProfile();
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `users/${firebaseUser.uid}`);
        }
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Google Sign In error:', error);
      throw error;
    }
  };

  const loginAsGuest = async (name: string, phone: string) => {
    try {
      const cred = await signInAnonymously(auth);
      const userRef = doc(db, 'users', cred.user.uid);
      const guestProfile = {
        id: cred.user.uid,
        email: `${phone.replace(/\s+/g, '')}@telebirr.et`,
        displayName: name,
        phoneNumber: phone,
        balance: 0,
        role: 'user',
        createdAt: new Date().toISOString(),
        totalBidsPlaced: 0,
        winsCount: 0,
      };
      await setDoc(userRef, guestProfile);
      setUserProfile({
        id: cred.user.uid,
        name,
        email: guestProfile.email,
        phone,
        walletBalanceETB: 0,
        totalBidsPlaced: 0,
        winsCount: 0,
      });
    } catch (error) {
      console.error('Guest sign in error:', error);
      throw error;
    }
  };

  const logout = async () => {
    await firebaseSignOut(auth);
    setUserProfile(null);
  };

  const updateBalance = async (newBalance: number) => {
    if (!currentUser) return;
    const userRef = doc(db, 'users', currentUser.uid);
    await updateDoc(userRef, { balance: newBalance });
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        isAdmin,
        loading,
        loginWithGoogle,
        loginAsGuest,
        logout,
        updateBalance,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
