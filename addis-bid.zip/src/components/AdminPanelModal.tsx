import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  Check,
  Ban,
  Clock,
  ArrowUpRight,
  TrendingUp,
  DollarSign,
  Users,
  Package,
  Sparkles,
} from 'lucide-react';
import {
  collection,
  onSnapshot,
  doc,
  updateDoc,
  increment,
  getDocs,
} from 'firebase/firestore';
import { db } from '../firebase';
import { formatETB } from '../utils/lubEngine';

interface DepositRecord {
  id: string;
  userId: string;
  userEmail: string;
  userName?: string;
  amount: number;
  method: string;
  transactionId: string;
  phoneNumber?: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  adminEmail: string;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  onClose,
  adminEmail,
}) => {
  const [deposits, setDeposits] = useState<DepositRecord[]>([]);
  const [activeTab, setActiveTab] = useState<'deposits' | 'overview'>('deposits');
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    // Real-time listener for all deposits
    const depositsRef = collection(db, 'deposits');
    const unsub = onSnapshot(depositsRef, (snapshot) => {
      const list: DepositRecord[] = [];
      snapshot.forEach((doc) => {
        list.push({ id: doc.id, ...(doc.data() as any) });
      });
      // Sort newest first
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setDeposits(list);
    });

    return () => unsub();
  }, [isOpen]);

  if (!isOpen) return null;

  const handleApproveDeposit = async (dep: DepositRecord) => {
    try {
      setActionLoading(dep.id);
      // 1. Update deposit status
      const depRef = doc(db, 'deposits', dep.id);
      await updateDoc(depRef, {
        status: 'approved',
        reviewedAt: new Date().toISOString(),
      });

      // 2. Increment user balance
      const userRef = doc(db, 'users', dep.userId);
      await updateDoc(userRef, {
        balance: increment(dep.amount),
      });
    } catch (err) {
      console.error('Failed to approve deposit:', err);
      alert('Error approving deposit');
    } finally {
      setActionLoading(null);
    }
  };

  const handleRejectDeposit = async (dep: DepositRecord) => {
    try {
      setActionLoading(dep.id);
      const depRef = doc(db, 'deposits', dep.id);
      await updateDoc(depRef, {
        status: 'rejected',
        reviewedAt: new Date().toISOString(),
      });
    } catch (err) {
      console.error('Failed to reject deposit:', err);
    } finally {
      setActionLoading(null);
    }
  };

  const pendingDeposits = deposits.filter((d) => d.status === 'pending');
  const totalApprovedETB = deposits
    .filter((d) => d.status === 'approved')
    .reduce((sum, d) => sum + d.amount, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/90 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-amber-500/30 rounded-2xl w-full max-w-4xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col relative my-auto">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-slate-800 flex items-center justify-between sticky top-0 bg-slate-900/95 backdrop-blur z-20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs">
                <span className="px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 font-bold font-mono">
                  PLATFORM OWNER
                </span>
                <span className="text-slate-400 font-mono text-[11px]">{adminEmail}</span>
              </div>
              <h2 className="font-display font-extrabold text-xl text-white">
                Addis Bid Admin Control Hub
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stats Row */}
        <div className="p-6 bg-slate-950/60 border-b border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
            <div className="text-xs text-slate-400">Pending Telebirr Verifications</div>
            <div className="text-2xl font-mono font-bold text-amber-400 mt-1">
              {pendingDeposits.length}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">Awaiting your approval</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
            <div className="text-xs text-slate-400">Total User Capital Approved</div>
            <div className="text-2xl font-mono font-bold text-emerald-400 mt-1">
              {formatETB(totalApprovedETB)}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">Deposited into user wallets</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
            <div className="text-xs text-slate-400">Total Processed Transactions</div>
            <div className="text-2xl font-mono font-bold text-white mt-1">
              {deposits.length}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">Telebirr & CBE ledger</div>
          </div>
        </div>

        {/* Pending Verification Table */}
        <div className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-lg text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-amber-400" />
              <span>Pending Telebirr & CBE Deposits ({pendingDeposits.length})</span>
            </h3>
            <span className="text-xs text-slate-400">Verify SMS Transaction ID before approving</span>
          </div>

          {pendingDeposits.length === 0 ? (
            <div className="py-12 text-center text-slate-500 text-sm rounded-xl border border-dashed border-slate-800 bg-slate-950/30">
              No pending deposits right now. All user transfers have been processed!
            </div>
          ) : (
            <div className="space-y-3">
              {pendingDeposits.map((dep) => (
                <div
                  key={dep.id}
                  className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold font-mono text-xs uppercase">
                        {dep.method}
                      </span>
                      <span className="font-mono font-bold text-white text-base">
                        {formatETB(dep.amount)}
                      </span>
                      <span className="text-xs text-slate-400">by {dep.userName || dep.userEmail}</span>
                    </div>

                    <div className="text-xs text-slate-400 flex flex-wrap gap-4 font-mono">
                      <span>Sender Phone: <strong className="text-slate-200">{dep.phoneNumber || 'N/A'}</strong></span>
                      <span>
                        Tx ID: <strong className="text-amber-400 bg-amber-400/10 px-1.5 py-0.5 rounded">{dep.transactionId}</strong>
                      </span>
                      <span className="text-slate-500">
                        {new Date(dep.createdAt).toLocaleTimeString()}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end md:self-auto shrink-0">
                    <button
                      onClick={() => handleRejectDeposit(dep)}
                      disabled={actionLoading === dep.id}
                      className="px-3 py-1.5 rounded-lg border border-rose-500/40 text-rose-300 hover:bg-rose-950/40 text-xs font-semibold flex items-center gap-1 transition-colors disabled:opacity-50"
                    >
                      <Ban className="w-3.5 h-3.5" />
                      <span>Reject</span>
                    </button>

                    <button
                      onClick={() => handleApproveDeposit(dep)}
                      disabled={actionLoading === dep.id}
                      className="px-4 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm disabled:opacity-50"
                    >
                      <Check className="w-4 h-4" />
                      <span>Approve & Credit {formatETB(dep.amount)}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Past Transactions Ledger */}
          <div className="pt-6 border-t border-slate-800">
            <h4 className="font-semibold text-sm text-slate-300 mb-3">Recently Processed Ledger</h4>
            <div className="max-h-60 overflow-y-auto space-y-2">
              {deposits
                .filter((d) => d.status !== 'pending')
                .slice(0, 10)
                .map((d) => (
                  <div
                    key={d.id}
                    className="p-3 rounded-lg bg-slate-950/40 border border-slate-800/80 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <span
                        className={`w-2 h-2 rounded-full ${
                          d.status === 'approved' ? 'bg-emerald-400' : 'bg-rose-400'
                        }`}
                      />
                      <span className="font-mono text-white font-bold">{formatETB(d.amount)}</span>
                      <span className="text-slate-400">{d.userName || d.userEmail}</span>
                      <span className="font-mono text-slate-500">[{d.transactionId}]</span>
                    </div>
                    <span
                      className={`font-semibold capitalize ${
                        d.status === 'approved' ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {d.status}
                    </span>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
