import React, { useState, useEffect } from 'react';
import {
  X,
  Clock,
  ShieldCheck,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  Info,
  Plus,
  Coins,
  Share2,
  Copy,
  Check,
  Send,
  Flame,
} from 'lucide-react';
import { AuctionItem, UserBid, UserProfile } from '../types/auction';
import { formatETB, formatUSD, formatTimeRemaining } from '../utils/lubEngine';

interface AuctionDetailModalProps {
  item: AuctionItem;
  user: UserProfile;
  currency: 'ETB' | 'USD';
  userBidsOnItem: UserBid[];
  onClose: () => void;
  onPlaceBid: (auctionId: string, amount: number) => boolean | Promise<boolean>;
  onPlaceSpreadBids: (auctionId: string, amounts: number[]) => void;
  onOpenWallet: () => void;
}

export const AuctionDetailModal: React.FC<AuctionDetailModalProps> = ({
  item,
  user,
  currency,
  userBidsOnItem,
  onClose,
  onPlaceBid,
  onPlaceSpreadBids,
  onOpenWallet,
}) => {
  const [bidAmountInput, setBidAmountInput] = useState<string>('2.15');
  const [activeTab, setActiveTab] = useState<'single' | 'spread'>('single');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [linkCopied, setLinkCopied] = useState<boolean>(false);

  // High-precision real-time countdown timer
  const [timeLeft, setTimeLeft] = useState<number>(() => Math.max(0, item.endTime - Date.now()));

  useEffect(() => {
    if (item.status === 'completed') return;

    const interval = setInterval(() => {
      const remaining = Math.max(0, item.endTime - Date.now());
      setTimeLeft(remaining);
      if (remaining <= 0) {
        clearInterval(interval);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [item.endTime, item.status]);

  const timer = formatTimeRemaining(timeLeft);
  const isCompleted = item.status === 'completed' || timeLeft <= 0;
  const isFinal5Minutes = !isCompleted && timeLeft > 0 && timeLeft <= 5 * 60 * 1000;

  // Social sharing helpers
  const shareUrl = typeof window !== 'undefined'
    ? `${window.location.origin}/?lot=${item.id}`
    : `https://ethiochareta.vercel.app/?lot=${item.id}`;

  const shareTitle = `Addis Bid | ${item.title}`;
  const shareText = `Check out "${item.title}" on Addis Bid! Retail value: ${formatETB(item.retailValueETB)}. Place secret bids to win at lowest unique price!`;

  const handleCopyLink = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(shareUrl);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = shareUrl;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2500);
    } catch (err) {
      console.error('Failed to copy link', err);
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          url: shareUrl,
        });
      } catch (err) {
        // User cancelled or share failed, fallback to copy
        handleCopyLink();
      }
    } else {
      handleCopyLink();
    }
  };

  const handleSingleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const val = parseFloat(bidAmountInput);
    if (isNaN(val) || val <= 0) {
      setErrorMsg('Please enter a valid positive bid amount.');
      return;
    }

    if (val > item.maxBidLimitETB) {
      setErrorMsg(`Maximum allowed secret bid for this item is ${formatETB(item.maxBidLimitETB)}.`);
      return;
    }

    if (user.walletBalanceETB < item.entryFeeETB) {
      setErrorMsg(`Insufficient wallet balance. You need ${formatETB(item.entryFeeETB)} to enter a bid.`);
      return;
    }

    const success = onPlaceBid(item.id, Number(val.toFixed(2)));
    if (success) {
      setSuccessMsg(`Secret bid of ${formatETB(val)} placed successfully!`);
      // slightly adjust input for next potential bid
      setBidAmountInput((val + 0.37).toFixed(2));
      setTimeout(() => setSuccessMsg(null), 4000);
    }
  };

  const handleSpreadSubmit = () => {
    setErrorMsg(null);
    setSuccessMsg(null);

    const feeNeeded = item.entryFeeETB * 3;
    if (user.walletBalanceETB < feeNeeded) {
      setErrorMsg(`Insufficient wallet balance. Placing 3 strategic spread bids requires ${formatETB(feeNeeded)}.`);
      return;
    }

    // Generate 3 non-round strategic micro-bids
    const base = parseFloat(bidAmountInput) || 2.5;
    const b1 = Number((Math.max(0.12, base * 0.7 + (Math.random() * 0.4))).toFixed(2));
    const b2 = Number((base + (Math.random() * 0.8)).toFixed(2));
    const b3 = Number((base * 1.5 + (Math.random() * 0.9)).toFixed(2));

    onPlaceSpreadBids(item.id, [b1, b2, b3]);
    setSuccessMsg(`3 Strategic Spread Bids placed (${formatETB(b1)}, ${formatETB(b2)}, ${formatETB(b3)})!`);
    setTimeout(() => setSuccessMsg(null), 4500);
  };

  const addStep = (step: number) => {
    const current = parseFloat(bidAmountInput) || 0;
    const nextVal = Math.max(0.01, current + step);
    setBidAmountInput(nextVal.toFixed(2));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col relative my-auto">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 sm:p-6 border-b border-slate-800 sticky top-0 bg-slate-900/95 backdrop-blur z-20">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span className="text-amber-400 font-semibold uppercase">{item.category}</span>
              <span aria-hidden="true">·</span>
              <span>Lot #{item.id.replace('auc-', '').toUpperCase()}</span>
            </div>
            <h2 className="font-display font-bold text-lg sm:text-xl text-white tracking-tight mt-0.5">
              {item.title}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Two-Column Split */}
        <div className="p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Visuals & Specifications */}
          <div className="lg:col-span-7 flex flex-col space-y-6">
            <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
              <img
                src={item.image}
                alt={item.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute top-3 left-3 bg-slate-950/90 border border-slate-800 px-3 py-1.5 rounded-lg text-xs text-white">
                <span className="text-slate-400 mr-2">Retail Market Value:</span>
                <span className="font-mono font-bold text-amber-300">
                  {currency === 'ETB' ? formatETB(item.retailValueETB) : formatUSD(item.retailValueUSD)}
                </span>
              </div>
            </div>

            <div>
              <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Item Description & Features
              </h4>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                {item.description}
              </p>
            </div>

            <div>
              <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Official Specifications & Warranty
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {item.specs.map((spec, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-amber-400 font-bold shrink-0">✓</span>
                    <span>{spec}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Fair-Play Cryptographic Commit Box */}
            <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-3 text-[11px] text-slate-400">
              <div className="flex items-center gap-1.5 text-slate-300 font-medium mb-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Cryptographically Sealed Fairness Hash</span>
              </div>
              <div className="font-mono text-[10px] text-slate-500 break-all select-all">
                {item.fairCommitHash}
              </div>
              <div className="mt-1 text-slate-500">
                Addis Bid uses deterministic hash commitments to prove results cannot be altered post-auction.
              </div>
            </div>
          </div>

          {/* Right Column: Contiguous Purchase / Secret Bidding Module */}
          <div className="lg:col-span-5 flex flex-col space-y-5">
            {/* Countdown Banner with 5-Minute Visual Pulse */}
            <div
              className={`rounded-xl p-4 transition-all duration-300 ${
                isFinal5Minutes
                  ? 'bg-rose-950/40 border-2 border-rose-500/80 shadow-lg shadow-rose-950/50 ring-1 ring-rose-500/40 animate-pulse'
                  : 'bg-slate-950 border border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    {isFinal5Minutes ? (
                      <span className="text-rose-400 font-semibold flex items-center gap-1">
                        <Flame className="w-3.5 h-3.5 text-rose-500 animate-bounce" />
                        Final 5 Minutes! (የመጨረሻ 5 ደቂቃ!)
                      </span>
                    ) : (
                      <span>Auction Timer</span>
                    )}
                  </div>
                  <div
                    className={`font-mono font-bold text-2xl tracking-wider tabular-nums mt-0.5 ${
                      isFinal5Minutes ? 'text-rose-200' : 'text-white'
                    }`}
                  >
                    {isCompleted ? (
                      <span className="text-emerald-400 text-lg">Ended (ተጠናቋል)</span>
                    ) : (
                      `${timer.hours}:${timer.minutes}:${timer.seconds}`
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400">Total Sealed Bids</span>
                  <div className="font-mono font-bold text-base text-amber-400 tabular-nums mt-0.5">
                    {item.totalBidsCount}
                  </div>
                </div>
              </div>

              {/* Urgent 5-Minute Warning Bar */}
              {isFinal5Minutes && (
                <div className="mt-2.5 pt-2 border-t border-rose-900/60 flex items-center gap-2 text-rose-200 text-xs">
                  <span className="relative flex h-2 w-2 shrink-0">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                  </span>
                  <span className="font-medium">
                    ⚡ Hurry! Auction closing soon. Submit your secret bid before the hash seal closes!
                  </span>
                </div>
              )}
            </div>

            {/* Social Sharing Section with Copy Link & Direct Platforms */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Share2 className="w-3.5 h-3.5 text-amber-400" />
                  Share this Auction (ይህን ዕቃ ያጋሩ)
                </span>
                <span className="text-[11px] text-slate-500">Earn credibility</span>
              </div>

              {/* One-click Copy Link input bar */}
              <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-lg p-1.5">
                <input
                  type="text"
                  readOnly
                  value={shareUrl}
                  className="bg-transparent text-slate-300 font-mono text-[11px] px-2 flex-1 outline-none truncate selection:bg-amber-500/30"
                />
                <button
                  type="button"
                  onClick={handleCopyLink}
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all flex items-center gap-1.5 shrink-0 active:scale-95 ${
                    linkCopied
                      ? 'bg-emerald-500 text-slate-950 shadow-sm'
                      : 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                  }`}
                >
                  {linkCopied ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Copied! (ተቀድቷል)</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Link</span>
                    </>
                  )}
                </button>
              </div>

              {/* Social Platform Quick Share Buttons */}
              <div className="grid grid-cols-4 gap-2 pt-0.5">
                {/* Telegram */}
                <a
                  href={`https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-1.5 px-2 bg-sky-950/40 hover:bg-sky-900/60 border border-sky-800/60 hover:border-sky-700 text-sky-300 rounded-lg text-[11px] font-medium flex items-center justify-center gap-1 transition-colors"
                  title="Share on Telegram"
                >
                  <Send className="w-3 h-3 text-sky-400" />
                  <span>Telegram</span>
                </a>

                {/* WhatsApp */}
                <a
                  href={`https://api.whatsapp.com/send?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-1.5 px-2 bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-800/60 hover:border-emerald-700 text-emerald-300 rounded-lg text-[11px] font-medium flex items-center justify-center gap-1 transition-colors"
                  title="Share on WhatsApp"
                >
                  <span className="font-bold text-[11px] text-emerald-400">WA</span>
                  <span>WhatsApp</span>
                </a>

                {/* X (Twitter) */}
                <a
                  href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-1.5 px-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-slate-600 text-slate-200 rounded-lg text-[11px] font-medium flex items-center justify-center gap-1 transition-colors"
                  title="Post on X"
                >
                  <span className="font-bold text-[11px]">𝕏</span>
                  <span>Post</span>
                </a>

                {/* More / Native Share */}
                <button
                  type="button"
                  onClick={handleNativeShare}
                  className="py-1.5 px-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-slate-600 text-amber-300 rounded-lg text-[11px] font-medium flex items-center justify-center gap-1 transition-colors"
                  title="Share via device"
                >
                  <Share2 className="w-3 h-3 text-amber-400" />
                  <span>More</span>
                </button>
              </div>
            </div>

            {/* Wallet Quick Status & Entry Fee */}
            <div className="bg-slate-800/40 border border-slate-800 rounded-xl p-3.5 flex items-center justify-between text-xs">
              <div>
                <span className="text-slate-400">Your Wallet Balance:</span>
                <div className="font-mono font-bold text-white tabular-nums mt-0.5">
                  {formatETB(user.walletBalanceETB)}
                </div>
              </div>
              <button
                onClick={onOpenWallet}
                className="text-amber-400 hover:text-amber-300 font-semibold underline underline-offset-4"
              >
                + Top Up Wallet
              </button>
            </div>

            {/* Bidding Controls Container */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
              {/* Segmented Mode Control */}
              <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg mb-4">
                <button
                  type="button"
                  onClick={() => setActiveTab('single')}
                  className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors ${
                    activeTab === 'single'
                      ? 'bg-amber-400 text-slate-950 font-semibold shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Single Secret Bid
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('spread')}
                  className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors ${
                    activeTab === 'spread'
                      ? 'bg-amber-400 text-slate-950 font-semibold shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  3x Strategic Spread
                </button>
              </div>

              {activeTab === 'single' ? (
                <form onSubmit={handleSingleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1.5">
                      Your Secret Target Price (ETB)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-mono font-semibold text-amber-400">
                        ETB
                      </span>
                      <input
                        type="number"
                        step="0.01"
                        min="0.01"
                        max={item.maxBidLimitETB}
                        value={bidAmountInput}
                        onChange={(e) => setBidAmountInput(e.target.value)}
                        className="w-full pl-14 pr-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg font-mono text-base font-bold text-white focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 tabular-nums"
                        placeholder="e.g. 2.45"
                        required
                      />
                    </div>
                  </div>

                  {/* Step Adjusters */}
                  <div className="flex items-center gap-1.5">
                    {[0.05, 0.1, 0.25, 0.5, 1.0].map((step) => (
                      <button
                        key={step}
                        type="button"
                        onClick={() => addStep(step)}
                        className="flex-1 py-1 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded text-[11px] font-mono text-slate-300 transition-colors"
                      >
                        +{step >= 1 ? step.toFixed(0) : step.toFixed(2)}
                      </button>
                    ))}
                  </div>

                  {/* Feedback Messages */}
                  {errorMsg && (
                    <div className="p-2.5 rounded-lg bg-rose-950/40 border border-rose-800/60 text-rose-300 text-xs flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <span>{errorMsg}</span>
                    </div>
                  )}

                  {successMsg && (
                    <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 text-xs flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{successMsg}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full py-3 px-4 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm rounded-lg transition-all shadow-md shadow-amber-400/20 active:scale-[0.98] flex items-center justify-center gap-2"
                  >
                    <span>Submit Secret Bid</span>
                    <span className="text-xs font-normal text-slate-800">
                      (Fee: {formatETB(item.entryFeeETB)})
                    </span>
                  </button>
                </form>
              ) : (
                <div className="space-y-4">
                  <div className="text-xs text-slate-400 leading-relaxed">
                    Strategic Spread Bidding places 3 calculated non-round bids simultaneously across different price brackets (e.g. low, mid, and hedge) to maximize your chances of securing an unshared unique number.
                  </div>

                  <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg text-xs space-y-1.5 text-slate-300">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Number of Bids:</span>
                      <span className="font-mono font-semibold">3 Secret Bids</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Total Entry Fee:</span>
                      <span className="font-mono font-semibold text-amber-400">
                        {formatETB(item.entryFeeETB * 3)}
                      </span>
                    </div>
                  </div>

                  {errorMsg && (
                    <div className="p-2.5 rounded-lg bg-rose-950/40 border border-rose-800/60 text-rose-300 text-xs flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <span>{errorMsg}</span>
                    </div>
                  )}

                  {successMsg && (
                    <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 text-xs flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{successMsg}</span>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={handleSpreadSubmit}
                    className="w-full py-3 px-4 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold text-sm rounded-lg transition-all shadow-md active:scale-[0.98] flex items-center justify-center gap-2"
                  >
                    <Sparkles className="w-4 h-4 text-slate-950" />
                    <span>Deploy 3x Strategic Spread</span>
                  </button>
                </div>
              )}
            </div>

            {/* User Active Bids on this Specific Auction */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-300">
                  Your Bids on this Lot ({userBidsOnItem.length})
                </span>
                <span className="text-slate-500 text-[11px]">Real-Time Status</span>
              </div>

              {userBidsOnItem.length === 0 ? (
                <div className="p-3 text-center rounded-lg border border-dashed border-slate-800 text-xs text-slate-500">
                  You haven't placed any secret bids on this lot yet. Enter a bid above to compete!
                </div>
              ) : (
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {userBidsOnItem.map((b) => (
                    <div
                      key={b.id}
                      className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="font-mono font-bold text-white tabular-nums">
                          {formatETB(b.amount)}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {new Date(b.placedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>

                      <div>
                        {b.status === 'unique_lowest' ? (
                          <span className="text-emerald-400 font-semibold flex items-center gap-1 text-[11px]">
                            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                            Unique & Lowest (Leading!)
                          </span>
                        ) : b.status === 'duplicated' ? (
                          <span className="text-rose-400 font-medium flex items-center gap-1 text-[11px]">
                            ⚠️ Duplicated (Cancelled Out)
                          </span>
                        ) : (
                          <span className="text-amber-400 font-medium text-[11px]">
                            Unique (Higher than lowest)
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
