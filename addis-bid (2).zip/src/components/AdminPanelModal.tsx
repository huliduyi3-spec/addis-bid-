import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  Check,
  Ban,
  Clock,
  ArrowUpRight,
  TrendingUp,
  DollarSign,
  Users,
  Package,
  Sparkles,
  Plus,
  Pencil,
  Trash2,
  Calendar,
  Image as ImageIcon,
  Tag,
  RefreshCw,
  Eye,
  Settings,
  CreditCard,
  Save,
  AlertTriangle,
} from 'lucide-react';
import {
  collection,
  onSnapshot,
  doc,
  updateDoc,
  increment,
  getDocs,
  setDoc,
  getDoc,
} from 'firebase/firestore';
import { db } from '../firebase';
import { formatETB, formatUSD } from '../utils/lubEngine';
import { AuctionItem, AuctionCategory } from '../types/auction';

interface DepositRecord {
  id: string;
  userId: string;
  userEmail: string;
  userName?: string;
  amount: number;
  method: string;
  transactionId: string;
  phoneNumber?: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

interface PaymentSettings {
  telebirrNumber: string;
  telebirrName: string;
  cbeAccount: string;
  cbeName: string;
  instructions: string;
}

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  adminEmail: string;
  auctions: AuctionItem[];
  onSaveAuction: (auction: AuctionItem) => Promise<void> | void;
  onDeleteAuction: (auctionId: string) => Promise<void> | void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  onClose,
  adminEmail,
  auctions,
  onSaveAuction,
  onDeleteAuction,
}) => {
  const [deposits, setDeposits] = useState<DepositRecord[]>([]);
  const [activeTab, setActiveTab] = useState<'auctions' | 'deposits' | 'payment-settings' | 'overview'>('auctions');
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // Auction Edit / Add Form State
  const [editingItem, setEditingItem] = useState<AuctionItem | null>(null);
  const [isNewItem, setIsNewItem] = useState<boolean>(false);
  const [isSavingAuction, setIsSavingAuction] = useState<boolean>(false);
  const [auctionSuccessMsg, setAuctionSuccessMsg] = useState<string | null>(null);
  const [auctionErrorMsg, setAuctionErrorMsg] = useState<string | null>(null);

  // Form Fields
  const [formTitle, setFormTitle] = useState('');
  const [formSubtitle, setFormSubtitle] = useState('');
  const [formCategory, setFormCategory] = useState<'vehicles' | 'smartphones' | 'laptops' | 'gaming'>('vehicles');
  const [formRetailETB, setFormRetailETB] = useState<number>(100000);
  const [formRetailUSD, setFormRetailUSD] = useState<number>(1000);
  const [formEntryFeeETB, setFormEntryFeeETB] = useState<number>(100);
  const [formMaxBidETB, setFormMaxBidETB] = useState<number>(500);
  const [formImage, setFormImage] = useState('');
  const [formCondition, setFormCondition] = useState('Brand New');
  const [formWarranty, setFormWarranty] = useState('1 Year Official Warranty');
  const [formEndTime, setFormEndTime] = useState<string>('');
  const [formStatus, setFormStatus] = useState<'live' | 'ending_soon' | 'completed'>('live');
  const [formSpecs, setFormSpecs] = useState('');
  const [formDescription, setFormDescription] = useState('');

  // Editable Payment Settings for Admin
  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings>({
    telebirrNumber: '09',
    telebirrName: '',
    cbeAccount: '1000',
    cbeName: '',
    instructions: 'ብር ሲያስገቡ በ SMS የመጣሎትን የደረሰኝ ቁጥር (Transaction ID) ሳጥኑ ውስጥ ይፃፉ።',
  });
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [settingsSavedMessage, setSettingsSavedMessage] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    // Load existing payment accounts
    const loadSettings = async () => {
      try {
        const snap = await getDoc(doc(db, 'settings', 'payment'));
        if (snap.exists()) {
          setPaymentSettings(snap.data() as PaymentSettings);
        }
      } catch (err) {
        console.error('Failed to load settings:', err);
      }
    };
    loadSettings();

    // Real-time listener for all deposits
    const depositsRef = collection(db, 'deposits');
    const unsub = onSnapshot(depositsRef, (snapshot) => {
      const list: DepositRecord[] = [];
      snapshot.forEach((doc) => {
        list.push({ id: doc.id, ...(doc.data() as any) });
      });
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setDeposits(list);
    });

    return () => unsub();
  }, [isOpen]);

  if (!isOpen) return null;

  // Open Form for creating new Auction
  const handleStartCreate = () => {
    setIsNewItem(true);
    const newId = `auc-${Date.now().toString().slice(-6)}`;
    const defaultEndTime = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000); // 3 days from now
    
    // Format to datetime-local string (YYYY-MM-DDTHH:mm)
    const tzOffset = defaultEndTime.getTimezoneOffset() * 60000;
    const localISOTime = new Date(defaultEndTime.getTime() - tzOffset).toISOString().slice(0, 16);

    setEditingItem({
      id: newId,
      title: '',
      subtitle: '',
      category: 'smartphones',
      retailValueETB: 120000,
      retailValueUSD: 1000,
      entryFeeETB: 50,
      image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=1200&q=80',
      specs: ['Original Box & Accessories', 'Unlocked to all networks in Ethiopia'],
      description: 'Brand new official lot with full guarantee. Lowest unique price wins!',
      condition: 'Brand New',
      warranty: '1 Year Warranty',
      totalBidsCount: 0,
      maxBidLimitETB: 200,
      endTime: defaultEndTime.getTime(),
      status: 'live',
      bids: [],
      fairCommitHash: 'sha256-' + Math.random().toString(36).substring(2) + Math.random().toString(36).substring(2),
    });

    setFormTitle('');
    setFormSubtitle('');
    setFormCategory('smartphones');
    setFormRetailETB(120000);
    setFormRetailUSD(1000);
    setFormEntryFeeETB(50);
    setFormMaxBidETB(200);
    setFormImage('https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=1200&q=80');
    setFormCondition('Brand New');
    setFormWarranty('1 Year Warranty');
    setFormEndTime(localISOTime);
    setFormStatus('live');
    setFormSpecs('Original Box & Accessories, Unlocked to all Ethiopian networks');
    setFormDescription('Brand new official lot with full guarantee. Lowest unique price wins!');
    setAuctionErrorMsg(null);
    setAuctionSuccessMsg(null);
  };

  // Open Form for editing existing Auction
  const handleStartEdit = (item: AuctionItem) => {
    setIsNewItem(false);
    setEditingItem(item);

    const date = new Date(item.endTime);
    const tzOffset = date.getTimezoneOffset() * 60000;
    const localISOTime = new Date(date.getTime() - tzOffset).toISOString().slice(0, 16);

    setFormTitle(item.title);
    setFormSubtitle(item.subtitle);
    setFormCategory(item.category);
    setFormRetailETB(item.retailValueETB);
    setFormRetailUSD(item.retailValueUSD);
    setFormEntryFeeETB(item.entryFeeETB);
    setFormMaxBidETB(item.maxBidLimitETB);
    setFormImage(item.image);
    setFormCondition(item.condition);
    setFormWarranty(item.warranty);
    setFormEndTime(localISOTime);
    setFormStatus(item.status);
    setFormSpecs(item.specs.join(', '));
    setFormDescription(item.description);
    setAuctionErrorMsg(null);
    setAuctionSuccessMsg(null);
  };

  // Quick Time Extension Handler (+hours or +days)
  const handleQuickExtend = async (item: AuctionItem, addedMs: number) => {
    try {
      const newEndTime = Math.max(Date.now(), item.endTime) + addedMs;
      const updatedItem: AuctionItem = {
        ...item,
        endTime: newEndTime,
        status: 'live',
      };
      await onSaveAuction(updatedItem);
      setAuctionSuccessMsg(`"${item.title}" ጊዜው በተሳካ ሁኔታ ተራዝሟል!`);
      setTimeout(() => setAuctionSuccessMsg(null), 3000);
    } catch (err) {
      console.error('Failed to extend time', err);
    }
  };

  // Save Auction Changes or New Item
  const handleSaveAuctionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;

    if (!formTitle.trim()) {
      setAuctionErrorMsg('እባክዎ የዕቃውን መጠሪያ ስም (Title) ያስገቡ');
      return;
    }

    if (formRetailETB <= 0 || formEntryFeeETB <= 0) {
      setAuctionErrorMsg('የገበያ ዋጋ እና የመጫረቻ ክፍያ ከ 0 በላይ መሆን አለባቸው');
      return;
    }

    const endTimestamp = new Date(formEndTime).getTime();
    if (isNaN(endTimestamp)) {
      setAuctionErrorMsg('ትክክለኛ የሚያበቃበት ቀን እና ሰዓት ያስገቡ');
      return;
    }

    setIsSavingAuction(true);
    setAuctionErrorMsg(null);

    const specsArray = formSpecs
      .split(',')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    const savedAuction: AuctionItem = {
      ...editingItem,
      title: formTitle.trim(),
      subtitle: formSubtitle.trim() || `${formCondition} - Official Listing`,
      category: formCategory,
      retailValueETB: Number(formRetailETB),
      retailValueUSD: Number(formRetailUSD) || Math.round(Number(formRetailETB) / 120),
      entryFeeETB: Number(formEntryFeeETB),
      maxBidLimitETB: Number(formMaxBidETB) || 500,
      image: formImage.trim() || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1000&q=80',
      condition: formCondition,
      warranty: formWarranty,
      endTime: endTimestamp,
      status: formStatus,
      specs: specsArray.length > 0 ? specsArray : ['Official Ethiopian Warranty'],
      description: formDescription.trim(),
    };

    try {
      await onSaveAuction(savedAuction);
      setAuctionSuccessMsg(isNewItem ? 'አዲሱ ዕቃ በተሳካ ሁኔታ ተለጥፏል! (Item Published)' : 'የዕቃው መረጃዎች በትክክል ተስተካክለው ተቀምጠዋል! (Saved)');
      setIsSavingAuction(false);
      setTimeout(() => {
        setEditingItem(null);
        setAuctionSuccessMsg(null);
      }, 1200);
    } catch (err: any) {
      console.error('Error saving auction:', err);
      setAuctionErrorMsg(err?.message || 'ዕቃውን ለማስቀመጥ አልተቻለም');
      setIsSavingAuction(false);
    }
  };

  // Delete Auction
  const handleDeleteItem = async (item: AuctionItem) => {
    const confirmDelete = window.confirm(`እርግጠኛ ነዎት "${item.title}" የሚለውን ዕቃ ከጨረታው ዝርዝር ውስጥ ማጥፋት ይፈልጋሉ?`);
    if (!confirmDelete) return;

    try {
      await onDeleteAuction(item.id);
      setAuctionSuccessMsg(`"${item.title}" በተሳካ ሁኔታ ተሰርዟል`);
      setTimeout(() => setAuctionSuccessMsg(null), 3000);
    } catch (err) {
      console.error('Failed to delete auction:', err);
    }
  };

  const handleSavePaymentSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingSettings(true);
    try {
      await setDoc(doc(db, 'settings', 'payment'), {
        ...paymentSettings,
        updatedAt: new Date().toISOString(),
        updatedBy: adminEmail,
      }, { merge: true });
      setSettingsSavedMessage(true);
      setTimeout(() => setSettingsSavedMessage(false), 3000);
    } catch (err) {
      console.error('Failed to save payment settings:', err);
      alert('Error saving payment settings');
    } finally {
      setIsSavingSettings(false);
    }
  };

  const handleApproveDeposit = async (dep: DepositRecord) => {
    try {
      setActionLoading(dep.id);
      const depRef = doc(db, 'deposits', dep.id);
      await updateDoc(depRef, {
        status: 'approved',
        reviewedAt: new Date().toISOString(),
      });

      const userRef = doc(db, 'users', dep.userId);
      await updateDoc(userRef, {
        walletBalanceETB: increment(dep.amount),
      });
    } catch (err) {
      console.error('Failed to approve deposit:', err);
    } finally {
      setActionLoading(null);
    }
  };

  const handleRejectDeposit = async (dep: DepositRecord) => {
    try {
      setActionLoading(dep.id);
      const depRef = doc(db, 'deposits', dep.id);
      await updateDoc(depRef, {
        status: 'rejected',
        reviewedAt: new Date().toISOString(),
      });
    } catch (err) {
      console.error('Failed to reject deposit:', err);
    } finally {
      setActionLoading(null);
    }
  };

  const pendingDeposits = deposits.filter((d) => d.status === 'pending');
  const totalApprovedETB = deposits
    .filter((d) => d.status === 'approved')
    .reduce((sum, d) => sum + d.amount, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/90 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-amber-500/30 rounded-2xl w-full max-w-5xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col relative my-auto">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-slate-800 flex items-center justify-between sticky top-0 bg-slate-900/95 backdrop-blur z-20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs">
                <span className="px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 font-bold font-mono">
                  PLATFORM OWNER
                </span>
                <span className="text-slate-400 font-mono text-[11px]">{adminEmail}</span>
              </div>
              <h2 className="font-display font-extrabold text-xl text-white">
                Addis Bid Admin Control Hub (የአድሚን መቆጣጠሪያ)
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global Feedback Banner */}
        {auctionSuccessMsg && (
          <div className="mx-6 mt-4 p-3 rounded-lg bg-emerald-950/60 border border-emerald-500 text-emerald-200 text-xs font-semibold flex items-center gap-2 animate-fadeIn">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{auctionSuccessMsg}</span>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="px-6 pt-4 border-b border-slate-800 flex items-center gap-2 overflow-x-auto">
          {/* Tab 1: Auctions & Lots Management */}
          <button
            onClick={() => {
              setEditingItem(null);
              setActiveTab('auctions');
            }}
            className={`pb-3 px-3 text-sm font-semibold border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
              activeTab === 'auctions'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>ዕቃዎች እና ጨረታዎች (Manage Lots)</span>
            <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-300">
              {auctions.length}
            </span>
          </button>

          {/* Tab 2: Deposit Approvals */}
          <button
            onClick={() => setActiveTab('deposits')}
            className={`pb-3 px-3 text-sm font-semibold border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
              activeTab === 'deposits'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>ክፍያዎችን አረጋግጥ (Verify Deposits)</span>
            {pendingDeposits.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-slate-950 animate-pulse">
                {pendingDeposits.length}
              </span>
            )}
          </button>

          {/* Tab 3: Payment Accounts */}
          <button
            onClick={() => setActiveTab('payment-settings')}
            className={`pb-3 px-3 text-sm font-semibold border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
              activeTab === 'payment-settings'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>የክፍያ ቁጥሮች (Payment Accounts)</span>
          </button>

          {/* Tab 4: Overview */}
          <button
            onClick={() => setActiveTab('overview')}
            className={`pb-3 px-3 text-sm font-semibold border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
              activeTab === 'overview'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>አጠቃላይ ሪፖርት (Overview)</span>
          </button>
        </div>

        {/* TAB 1: AUCTIONS & LOTS MANAGEMENT */}
        {activeTab === 'auctions' && (
          <div className="p-4 sm:p-6 space-y-6">
            {/* If in edit/create mode: render item form */}
            {editingItem ? (
              <form onSubmit={handleSaveAuctionSubmit} className="space-y-5 bg-slate-950/80 p-5 rounded-xl border border-slate-800">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <Pencil className="w-4 h-4 text-amber-400" />
                      <span>{isNewItem ? 'አዲስ የጨረታ ዕቃ ፖስት ማድረጊያ' : `ዕቃውን አስተካክል: ${editingItem.title}`}</span>
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      ዋጋዎችን፣ ቀኖችን፣ ፎቶዎችን እና መግለጫዎችን እዚህ ይቀይሩ
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setEditingItem(null)}
                    className="text-xs text-slate-400 hover:text-white px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg"
                  >
                    ተመለስ (Cancel)
                  </button>
                </div>

                {auctionErrorMsg && (
                  <div className="p-3 bg-rose-950/40 border border-rose-500 rounded-lg text-rose-300 text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{auctionErrorMsg}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Title */}
                  <div className="md:col-span-2">
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      የዕቃው መጠሪያ ስም (Item Title) *
                    </label>
                    <input
                      type="text"
                      value={formTitle}
                      onChange={(e) => setFormTitle(e.target.value)}
                      placeholder="ለምሳሌ፡ iPhone 16 Pro Max 256GB Desert Titanium"
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:border-amber-400 focus:outline-none"
                      required
                    />
                  </div>

                  {/* Subtitle */}
                  <div className="md:col-span-2">
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      አጭር ማብራሪያ (Subtitle)
                    </label>
                    <input
                      type="text"
                      value={formSubtitle}
                      onChange={(e) => setFormSubtitle(e.target.value)}
                      placeholder="ለምሳሌ፡ Brand New 0km In Box with 1 Year Apple Warranty"
                      className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none"
                    />
                  </div>

                  {/* Category */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      ምድብ (Category)
                    </label>
                    <select
                      value={formCategory}
                      onChange={(e) => setFormCategory(e.target.value as any)}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none"
                    >
                      <option value="smartphones">📱 ስማርትፎኖች (Smartphones)</option>
                      <option value="vehicles">🚗 ተሽከርካሪዎች (Vehicles & Cars)</option>
                      <option value="laptops">💻 ላፕቶፖች (Laptops & Computers)</option>
                      <option value="gaming">🎮 ጌሚንግ (Gaming & Consoles)</option>
                    </select>
                  </div>

                  {/* Status */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      የጨረታው ሁኔታ (Status)
                    </label>
                    <select
                      value={formStatus}
                      onChange={(e) => setFormStatus(e.target.value as any)}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none"
                    >
                      <option value="live">🟢 Live (ክፍት ጨረታ)</option>
                      <option value="ending_soon">🟡 Ending Soon (በቅርቡ የሚጠናቀቅ)</option>
                      <option value="completed">🔴 Completed (የተጠናቀቀ)</option>
                    </select>
                  </div>

                  {/* Retail Value ETB */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      ትክክለኛ የገበያ ዋጋ በብር (Retail Value ETB) *
                    </label>
                    <input
                      type="number"
                      step="1"
                      min="1"
                      value={formRetailETB}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value) || 0;
                        setFormRetailETB(val);
                        setFormRetailUSD(Math.round(val / 120));
                      }}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-amber-300 font-mono font-bold text-sm focus:border-amber-400 focus:outline-none"
                      required
                    />
                  </div>

                  {/* Entry Fee ETB */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      የአንድ ጨረታ መግቢያ ክፍያ በብር (Entry Fee ETB) *
                    </label>
                    <input
                      type="number"
                      step="1"
                      min="1"
                      value={formEntryFeeETB}
                      onChange={(e) => setFormEntryFeeETB(parseFloat(e.target.value) || 0)}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-amber-300 font-mono font-bold text-sm focus:border-amber-400 focus:outline-none"
                      required
                    />
                  </div>

                  {/* Max Bid Limit */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      ከፍተኛው የሚፈቀድ ሚስጥር ዋጋ (Max Bid Limit ETB)
                    </label>
                    <input
                      type="number"
                      step="1"
                      min="1"
                      value={formMaxBidETB}
                      onChange={(e) => setFormMaxBidETB(parseFloat(e.target.value) || 500)}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm focus:border-amber-400 focus:outline-none"
                    />
                    <span className="text-[10px] text-slate-500">ተጫራቹ ከዚህ በላይ ማስገባት አይችልም (ለምሳሌ፡ 500 ብር)</span>
                  </div>

                  {/* End Date & Time with Quick Presets */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      የሚያበቃበት ቀን እና ሰዓት (End Date & Time) *
                    </label>
                    <input
                      type="datetime-local"
                      value={formEndTime}
                      onChange={(e) => setFormEndTime(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-xs focus:border-amber-400 focus:outline-none"
                      required
                    />
                    {/* Quick Extend Buttons */}
                    <div className="flex items-center gap-1 mt-1.5">
                      <span className="text-[10px] text-slate-500 mr-1">ቀነ-ቀጠሮ አራዝም:</span>
                      {[
                        { label: '+2 ሰዓት', ms: 2 * 3600 * 1000 },
                        { label: '+1 ቀን', ms: 24 * 3600 * 1000 },
                        { label: '+3 ቀን', ms: 3 * 24 * 3600 * 1000 },
                        { label: '+1 ሳምንት', ms: 7 * 24 * 3600 * 1000 },
                      ].map((preset) => (
                        <button
                          key={preset.label}
                          type="button"
                          onClick={() => {
                            const cur = new Date(formEndTime).getTime() || Date.now();
                            const next = new Date(cur + preset.ms);
                            const tzOffset = next.getTimezoneOffset() * 60000;
                            setFormEndTime(new Date(next.getTime() - tzOffset).toISOString().slice(0, 16));
                          }}
                          className="px-2 py-0.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded text-[10px] text-amber-300"
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Image URL & Live Preview */}
                  <div className="md:col-span-2">
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      የፎቶ ሊንክ / ምስል (Image URL)
                    </label>
                    <div className="flex items-center gap-3">
                      <input
                        type="url"
                        value={formImage}
                        onChange={(e) => setFormImage(e.target.value)}
                        placeholder="https://images.unsplash.com/photo-..."
                        className="flex-1 px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none"
                      />
                      {formImage && (
                        <div className="w-12 h-12 rounded-lg border border-slate-700 overflow-hidden bg-slate-900 shrink-0">
                          <img
                            src={formImage}
                            alt="Preview"
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as any).src = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1000&q=80';
                            }}
                          />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Specifications */}
                  <div className="md:col-span-2">
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      ዝርዝር መረጃዎች (Specs - በኮማ ይለያዩ)
                    </label>
                    <input
                      type="text"
                      value={formSpecs}
                      onChange={(e) => setFormSpecs(e.target.value)}
                      placeholder="ለምሳሌ፡ 256GB Storage, 8GB RAM, 48MP Camera, Original Box"
                      className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none"
                    />
                  </div>

                  {/* Description */}
                  <div className="md:col-span-2">
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      ሙሉ ማብራሪያ (Full Description)
                    </label>
                    <textarea
                      rows={3}
                      value={formDescription}
                      onChange={(e) => setFormDescription(e.target.value)}
                      className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Submit Actions */}
                <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setEditingItem(null)}
                    className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium"
                  >
                    ተመለስ (Cancel)
                  </button>
                  <button
                    type="submit"
                    disabled={isSavingAuction}
                    className="px-6 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-lg text-xs transition-all shadow-md shadow-amber-400/20 flex items-center gap-2 active:scale-95 disabled:opacity-50"
                  >
                    <Save className="w-4 h-4" />
                    <span>{isSavingAuction ? 'እየተቀመጠ ነው...' : isNewItem ? 'ዕቃውን ፖስት አድርግ (Publish)' : 'ለውጦችን መዝግብ (Save Changes)'}</span>
                  </button>
                </div>
              </form>
            ) : (
              // Lot catalog list view
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div>
                    <h3 className="font-bold text-white text-base">የቀጥታ ጨረታዎች ካታሎግ (Live Lots Catalog)</h3>
                    <p className="text-xs text-slate-400">ዋጋዎችን እና ቀኖችን ለማስተካከል "አስተካክል" የሚለውን ይጫኑ</p>
                  </div>
                  <button
                    onClick={handleStartCreate}
                    className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-lg transition-all shadow-sm flex items-center gap-1.5 active:scale-95"
                  >
                    <Plus className="w-4 h-4" />
                    <span>+ አዲስ ዕቃ ፖስት አድርግ</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {auctions.map((item) => {
                    const isEnded = item.status === 'completed' || item.endTime <= Date.now();
                    const timeLeftMs = Math.max(0, item.endTime - Date.now());
                    const hoursLeft = Math.floor(timeLeftMs / (3600 * 1000));
                    const daysLeft = Math.floor(hoursLeft / 24);

                    return (
                      <div
                        key={item.id}
                        className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between hover:border-slate-700 transition-all space-y-3"
                      >
                        <div className="flex items-start gap-3">
                          <img
                            src={item.image}
                            alt={item.title}
                            className="w-16 h-16 rounded-lg object-cover bg-slate-900 border border-slate-800 shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                                {item.category}
                              </span>
                              <span
                                className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                                  isEnded
                                    ? 'bg-slate-800 text-slate-400'
                                    : 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                                }`}
                              >
                                {isEnded ? 'ተጠናቋል' : '🟢 Live'}
                              </span>
                            </div>
                            <h4 className="font-bold text-white text-sm truncate mt-0.5" title={item.title}>
                              {item.title}
                            </h4>
                            <div className="flex items-center gap-3 text-xs mt-1">
                              <div>
                                <span className="text-slate-500 text-[11px]">ዋጋ: </span>
                                <span className="font-mono font-bold text-amber-300">
                                  {formatETB(item.retailValueETB)}
                                </span>
                              </div>
                              <div>
                                <span className="text-slate-500 text-[11px]">መግቢያ: </span>
                                <span className="font-mono text-slate-200">
                                  {formatETB(item.entryFeeETB)}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Timing info */}
                        <div className="p-2 bg-slate-900/80 rounded-lg text-xs flex items-center justify-between border border-slate-800/60">
                          <div className="flex items-center gap-1.5 text-slate-400 text-[11px]">
                            <Calendar className="w-3.5 h-3.5 text-amber-400" />
                            <span>
                              {isEnded ? 'ጊዜው አልቋል' : daysLeft > 0 ? `${daysLeft} ቀንና ${hoursLeft % 24} ሰዓት ቀረ` : `${hoursLeft} ሰዓት ቀረ`}
                            </span>
                          </div>
                          <span className="text-[11px] text-slate-400 font-mono">
                            {new Date(item.endTime).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>

                        {/* Actions Toolbar */}
                        <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800/80">
                          {/* Quick Extend Buttons */}
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleQuickExtend(item, 24 * 3600 * 1000)}
                              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-medium transition-colors"
                              title="ጨረታውን በ 1 ቀን አራዝም"
                            >
                              +1 ቀን
                            </button>
                            <button
                              type="button"
                              onClick={() => handleQuickExtend(item, 3 * 24 * 3600 * 1000)}
                              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-medium transition-colors"
                              title="ጨረታውን በ 3 ቀናት አራዝም"
                            >
                              +3 ቀን
                            </button>
                          </div>

                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => handleStartEdit(item)}
                              className="px-3 py-1.5 bg-amber-400/15 hover:bg-amber-400/25 border border-amber-400/40 text-amber-300 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                              <span>አስተካክል (Edit)</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteItem(item)}
                              className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 rounded-lg transition-colors"
                              title="ዕቃውን ሰርዝ"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: DEPOSIT APPROVALS */}
        {activeTab === 'deposits' && (
          <div className="p-4 sm:p-6 space-y-6">
            <h3 className="font-bold text-white text-base">የተጠቃሚዎች የቴሌብር እና ሲቢኢ ክፍያዎች ማረጋገጫ</h3>

            {pendingDeposits.length === 0 ? (
              <div className="p-8 text-center rounded-xl bg-slate-950/40 border border-slate-800">
                <Check className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                <h4 className="font-semibold text-white">ምንም ያልተረጋገጠ አዲስ ክፍያ የለም (All caught up)</h4>
                <p className="text-xs text-slate-400 mt-1">
                  ተጠቃሚዎች በቴሌብር ወይም በሲቢኢ ብር ሲያስገቡ እዚህ ዝርዝር ውስጥ ይመጣሉ።
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {pendingDeposits.map((dep) => (
                  <div
                    key={dep.id}
                    className="p-4 rounded-xl bg-slate-950 border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-lg font-bold text-emerald-400">
                          {formatETB(dep.amount)}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-800 text-amber-300">
                          {dep.method}
                        </span>
                      </div>
                      <div className="text-xs text-slate-300 mt-1">
                        ተጠቃሚ: <span className="font-semibold">{dep.userName || dep.userEmail}</span>
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
                        <span>የደረሰኝ ቁጥር (TxID):</span>
                        <span className="font-mono text-white font-bold select-all bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                          {dep.transactionId}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-500 mt-1">
                        የገባበት ሰዓት: {new Date(dep.createdAt).toLocaleString()}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      <button
                        onClick={() => handleRejectDeposit(dep)}
                        disabled={actionLoading === dep.id}
                        className="flex-1 sm:flex-none px-3 py-2 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/60 text-rose-300 rounded-lg text-xs font-semibold transition-colors disabled:opacity-50"
                      >
                        ውድቅ አድርግ
                      </button>
                      <button
                        onClick={() => handleApproveDeposit(dep)}
                        disabled={actionLoading === dep.id}
                        className="flex-1 sm:flex-none px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-lg text-xs font-bold transition-all shadow-md active:scale-95 disabled:opacity-50 flex items-center justify-center gap-1.5"
                      >
                        <Check className="w-4 h-4" />
                        <span>አጽድቅ & {formatETB(dep.amount)} አስገባ</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Recently Processed Ledger */}
            <div className="pt-6 border-t border-slate-800">
              <h4 className="font-semibold text-sm text-slate-300 mb-3">ያለፉ ክፍያዎች ማህደር (Processed Ledger)</h4>
              <div className="max-h-60 overflow-y-auto space-y-2">
                {deposits
                  .filter((d) => d.status !== 'pending')
                  .slice(0, 10)
                  .map((d) => (
                    <div
                      key={d.id}
                      className="p-3 rounded-lg bg-slate-950/40 border border-slate-800/80 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className={`w-2 h-2 rounded-full ${
                            d.status === 'approved' ? 'bg-emerald-400' : 'bg-rose-400'
                          }`}
                        />
                        <span className="font-mono text-white font-bold">{formatETB(d.amount)}</span>
                        <span className="text-slate-400">{d.userName || d.userEmail}</span>
                        <span className="font-mono text-slate-500">[{d.transactionId}]</span>
                      </div>
                      <span
                        className={`font-semibold capitalize ${
                          d.status === 'approved' ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {d.status}
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: PAYMENT SETTINGS */}
        {activeTab === 'payment-settings' && (
          <div className="p-4 sm:p-6 space-y-6">
            <div>
              <h3 className="font-bold text-white text-base">ተጠቃሚዎች ብር የሚያስገቡባቸውን ቁጥሮች ማስተካከያ</h3>
              <p className="text-xs text-slate-400 mt-1">
                እዚህ የሚሞሉት የቴሌብር እና ሲቢኢ ቁጥሮች በሙሉ ተጠቃሚዎች ብር ለማስገባት ሲከፍቱ ይታዩላቸዋል።
              </p>
            </div>

            {settingsSavedMessage && (
              <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-500 text-emerald-200 text-xs font-semibold flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>የክፍያ ቁጥሮች በተሳካ ሁኔታ ተቀምጠዋል! (Payment accounts updated)</span>
              </div>
            )}

            <form onSubmit={handleSavePaymentSettings} className="space-y-4 max-w-xl">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                  <span>📱 የቴሌብር (Telebirr) መረጃዎች</span>
                </h4>
                <div>
                  <label className="block text-xs text-slate-300 mb-1">የቴሌብር ስልክ ቁጥር</label>
                  <input
                    type="text"
                    value={paymentSettings.telebirrNumber}
                    onChange={(e) => setPaymentSettings({ ...paymentSettings, telebirrNumber: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm focus:border-amber-400 focus:outline-none"
                    placeholder="0911223344"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-300 mb-1">የመለያው ባለቤት ስም (Account Name)</label>
                  <input
                    type="text"
                    value={paymentSettings.telebirrName}
                    onChange={(e) => setPaymentSettings({ ...paymentSettings, telebirrName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:border-amber-400 focus:outline-none"
                    placeholder="ለምሳሌ፡ አበበ ከበደ"
                    required
                  />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                  <span>🏦 የንግድ ባንክ (CBE) መረጃዎች</span>
                </h4>
                <div>
                  <label className="block text-xs text-slate-300 mb-1">የሲቢኢ አካውንት ቁጥር</label>
                  <input
                    type="text"
                    value={paymentSettings.cbeAccount}
                    onChange={(e) => setPaymentSettings({ ...paymentSettings, cbeAccount: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm focus:border-amber-400 focus:outline-none"
                    placeholder="1000..."
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-300 mb-1">የአካውንቱ ባለቤት ስም (Account Holder Name)</label>
                  <input
                    type="text"
                    value={paymentSettings.cbeName}
                    onChange={(e) => setPaymentSettings({ ...paymentSettings, cbeName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:border-amber-400 focus:outline-none"
                    placeholder="ለምሳሌ፡ አበበ ከበደ"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">ለተጠቃሚዎች የሚታይ መመሪያ (Instructions)</label>
                <textarea
                  rows={2}
                  value={paymentSettings.instructions}
                  onChange={(e) => setPaymentSettings({ ...paymentSettings, instructions: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSavingSettings}
                className="w-full py-2.5 px-4 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-lg transition-all shadow-md active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                <Save className="w-4 h-4" />
                <span>{isSavingSettings ? 'እየተቀመጠ ነው...' : 'የክፍያ ቁጥሮችን መዝግብ (Save Accounts)'}</span>
              </button>
            </form>
          </div>
        )}

        {/* TAB 4: OVERVIEW METRICS */}
        {activeTab === 'overview' && (
          <div className="p-4 sm:p-6 space-y-6">
            <h3 className="font-bold text-white text-base">የፕላትፎርሙ አጠቃላይ ቁጥሮች እና ሁኔታ</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-xs text-slate-400">ንቁ ጨረታዎች</div>
                <div className="text-2xl font-bold font-mono text-amber-400 mt-1">
                  {auctions.filter((a) => a.status === 'live').length}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-xs text-slate-400">የተጠናቀቁ ጨረታዎች</div>
                <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
                  {auctions.filter((a) => a.status === 'completed').length}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-xs text-slate-400">ያልተረጋገጡ ክፍያዎች</div>
                <div className="text-2xl font-bold font-mono text-rose-400 mt-1">
                  {pendingDeposits.length}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-xs text-slate-400">የገቡ አጠቃላይ ክፍያዎች</div>
                <div className="text-2xl font-bold font-mono text-white mt-1">
                  {formatETB(totalApprovedETB)}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
