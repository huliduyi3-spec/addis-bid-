import React, { useState } from 'react';
import { X, Sparkles, Phone, ShieldCheck, ArrowRight, Mail, Lock, User, AlertCircle, KeyRound, Check } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultMode?: 'login' | 'signup';
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, defaultMode = 'login' }) => {
  const { loginWithEmail, registerWithEmail, loginWithGoogle, loginAsGuest, resetPassword } = useAuth();
  
  const [authMode, setAuthMode] = useState<'login' | 'signup'>(defaultMode);
  const [method, setMethod] = useState<'email' | 'phone'>('email');
  
  // Form fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('09');
  
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [showForgot, setShowForgot] = useState(false);

  if (!isOpen) return null;

  const translateFirebaseError = (err: any): string => {
    const code = err?.code || err?.message || '';
    if (code.includes('unauthorized-domain')) {
      return 'unauthorized-domain';
    }
    if (code.includes('invalid-credential') || code.includes('wrong-password')) {
      return 'የተሳሳተ ኢሜይል ወይም የይለፍ ቃል አስገብተዋል (Incorrect email or password).';
    }
    if (code.includes('user-not-found')) {
      return 'ይህ አካውንት አልተገኘም። እባክዎ አስቀድመው ይመዝገቡ (Account not found. Please register).';
    }
    if (code.includes('email-already-in-use')) {
      return 'ይህ ኢሜይል አስቀድሞ ተመዝግቧል! እባክዎ "ግባ (Log In)" የሚለውን ይጫኑ (Email already in use).';
    }
    if (code.includes('weak-password')) {
      return 'የይለፍ ቃል ቢያንስ 6 ፊደላት/ቁጥሮች መሆን አለበት (Password must be at least 6 characters).';
    }
    if (code.includes('invalid-email')) {
      return 'እባክዎ ትክክለኛ የኢሜይል አድራሻ ያስገቡ (Please enter a valid email address).';
    }
    if (code.includes('popup-closed-by-user')) {
      return 'የ Google መግቢያ ተሰርዟል (Google sign-in popup was closed).';
    }
    return err?.message || 'ስህተት ተከስቷል፣ እባክዎ እንደገና ይሞክሩ (An error occurred).';
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) {
      setErrorMsg('እባክዎ ኢሜይል እና የይለፍ ቃልዎን ያስገቡ (Please fill in email and password).');
      return;
    }

    try {
      setLoading(true);
      setErrorMsg('');
      setSuccessMsg('');
      await loginWithEmail(email, password);
      onClose();
    } catch (err: any) {
      setErrorMsg(translateFirebaseError(err));
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (method === 'email') {
      if (!fullName.trim() || !email.trim() || !password) {
        setErrorMsg('እባክዎ ሙሉ ስም፣ ኢሜይል እና የይለፍ ቃል ያስገቡ (Please fill all fields).');
        return;
      }
      if (password.length < 6) {
        setErrorMsg('የይለፍ ቃል ቢያንስ 6 ፊደል መሆን አለበት (Password must be 6+ chars).');
        return;
      }
      try {
        setLoading(true);
        setErrorMsg('');
        await registerWithEmail(email, password, fullName.trim(), phone.trim());
        onClose();
      } catch (err: any) {
        setErrorMsg(translateFirebaseError(err));
      } finally {
        setLoading(false);
      }
    } else {
      // Quick phone registration
      if (!fullName.trim() || phone.length < 9) {
        setErrorMsg('እባክዎ ሙሉ ስም እና ትክክለኛ ስልክ ቁጥር ያስገቡ (Enter name & valid phone).');
        return;
      }
      try {
        setLoading(true);
        setErrorMsg('');
        await loginAsGuest(fullName.trim(), phone.trim());
        onClose();
      } catch (err: any) {
        setErrorMsg(translateFirebaseError(err));
      } finally {
        setLoading(false);
      }
    }
  };

  const handleGoogleLogin = async () => {
    try {
      setLoading(true);
      setErrorMsg('');
      await loginWithGoogle();
      onClose();
    } catch (err: any) {
      setErrorMsg(translateFirebaseError(err));
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setErrorMsg('እባክዎ ኢሜይልዎን ያስገቡ (Enter your email).');
      return;
    }
    try {
      setLoading(true);
      setErrorMsg('');
      await resetPassword(email);
      setSuccessMsg('የይለፍ ቃል ማስተካከያ ሊንክ ወደ ኢሜይልዎ ተልኳል (Reset link sent to your email).');
    } catch (err: any) {
      setErrorMsg(translateFirebaseError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl p-6 relative flex flex-col max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/20">
            <Sparkles className="w-5 h-5 text-slate-950" />
          </div>
          <div>
            <h3 className="text-xl font-display font-bold text-white leading-tight">
              {authMode === 'login' ? 'ወደ አዲስ ቢድ ይግቡ' : 'አዲስ አካውንት ይክፈቱ'}
            </h3>
            <p className="text-xs text-slate-400">
              {authMode === 'login' ? 'Sign in to place bids & deposit' : 'Register with Telebirr & Email'}
            </p>
          </div>
        </div>

        {/* Tab Switcher: Login vs Sign Up */}
        <div className="grid grid-cols-2 p-1 bg-slate-950 border border-slate-800 rounded-xl text-xs font-bold mb-5">
          <button
            type="button"
            onClick={() => {
              setAuthMode('login');
              setShowForgot(false);
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`py-2.5 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              authMode === 'login'
                ? 'bg-amber-400 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>ግባ (Log In)</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMode('signup');
              setShowForgot(false);
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`py-2.5 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              authMode === 'signup'
                ? 'bg-amber-400 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>ተመዝገብ (Sign Up)</span>
          </button>
        </div>

        {/* Alerts */}
        {errorMsg === 'unauthorized-domain' ? (
          <div className="p-3.5 mb-4 rounded-xl bg-amber-950/70 border border-amber-600/70 text-amber-200 text-xs space-y-2.5">
            <div className="flex items-start gap-2 font-semibold text-amber-300">
              <AlertCircle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
              <span>Google Sign-In Domain ፈቃድ ይፈልጋል</span>
            </div>
            <p className="text-[11px] text-amber-100/90 leading-relaxed">
              Google Login በ <strong>{window.location.hostname}</strong> ላይ እንዲሰራ በ Firebase Console → Authentication → Settings → Authorized Domains ውስጥ መመዝገብ አለበት።
            </p>
            <div className="pt-2 border-t border-amber-800/60 space-y-1.5">
              <span className="text-[11px] font-bold text-white block">አሁኑኑ ያለ Google ለመግባት፦</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('login');
                    setErrorMsg('');
                  }}
                  className="py-1.5 px-2 bg-amber-400 text-slate-950 rounded-lg font-bold text-[11px] hover:bg-amber-300 transition-colors text-center"
                >
                  📧 በኢሜይል ግባ
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('signup');
                    setMethod('phone');
                    setErrorMsg('');
                  }}
                  className="py-1.5 px-2 bg-slate-800 text-white rounded-lg font-bold text-[11px] hover:bg-slate-700 transition-colors text-center"
                >
                  📱 በቴሌብር ተመዝገብ
                </button>
              </div>
            </div>
          </div>
        ) : errorMsg ? (
          <div className="p-3 mb-4 rounded-xl bg-rose-950/60 border border-rose-800/80 text-rose-300 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        ) : null}

        {successMsg && (
          <div className="p-3 mb-4 rounded-xl bg-emerald-950/60 border border-emerald-800/80 text-emerald-300 text-xs flex items-start gap-2">
            <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* LOGIN FORM */}
        {authMode === 'login' && !showForgot && (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">ኢሜይል (Email)</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="mameboss98@gmail.com ወይም user@gmail.com"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:border-amber-400 placeholder:text-slate-600"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300">የይለፍ ቃል (Password)</label>
                <button
                  type="button"
                  onClick={() => setShowForgot(true)}
                  className="text-[11px] text-amber-400 hover:underline"
                >
                  ረሱት? (Forgot?)
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:border-amber-400 placeholder:text-slate-600"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 px-4 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-md shadow-amber-400/20 active:scale-[0.98] disabled:opacity-50"
            >
              <span>{loading ? 'እየገባ ነው...' : 'ግባ (Log In)'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* Google Divider */}
            <div className="relative my-4 flex items-center justify-center">
              <div className="border-t border-slate-800 w-full" />
              <span className="bg-slate-900 px-3 text-[11px] text-slate-500 font-medium">ወይም (OR)</span>
            </div>

            <button
              type="button"
              onClick={handleGoogleLogin}
              disabled={loading}
              className="w-full py-2.5 px-4 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-white rounded-xl font-semibold text-xs flex items-center justify-center gap-3 transition-colors disabled:opacity-50"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>በ Google መለያ ይግቡ (Sign In with Google)</span>
            </button>
          </form>
        )}

        {/* FORGOT PASSWORD FORM */}
        {showForgot && (
          <form onSubmit={handleForgotPassword} className="space-y-4">
            <p className="text-xs text-slate-300">
              የተመዘገቡበትን ኢሜይል ያስገቡ፣ የይለፍ ቃል ማስተካከያ ሊንክ እንልክልዎታለን።
            </p>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">ኢሜይል (Email)</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="yourname@gmail.com"
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:border-amber-400"
              />
            </div>
            <div className="flex items-center gap-2">
              <button
                type="submit"
                disabled={loading}
                className="flex-1 py-2.5 px-4 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl font-bold text-xs"
              >
                {loading ? 'በመላክ ላይ...' : 'ሊንክ ላክ (Send Reset Link)'}
              </button>
              <button
                type="button"
                onClick={() => setShowForgot(false)}
                className="py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs"
              >
                ተመለስ
              </button>
            </div>
          </form>
        )}

        {/* SIGN UP / REGISTER FORM */}
        {authMode === 'signup' && (
          <div className="space-y-4">
            {/* Method switch */}
            <div className="flex items-center gap-2 text-xs">
              <button
                type="button"
                onClick={() => setMethod('email')}
                className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
                  method === 'email'
                    ? 'border-amber-400 bg-amber-400/10 text-amber-300'
                    : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
                }`}
              >
                📧 በኢሜይል እና ፓስዎርድ
              </button>
              <button
                type="button"
                onClick={() => setMethod('phone')}
                className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
                  method === 'phone'
                    ? 'border-amber-400 bg-amber-400/10 text-amber-300'
                    : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
                }`}
              >
                📱 በቴሌብር ስልክ ብቻ
              </button>
            </div>

            <form onSubmit={handleSignUp} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">ሙሉ ስም (Full Name)</label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="ለምሳሌ፡ ዮናስ በቀለ"
                    className="w-full pl-10 pr-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {method === 'email' ? (
                <>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">ኢሜይል (Email)</label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="name@gmail.com"
                        className="w-full pl-10 pr-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">የቴሌብር ስልክ (Phone Number)</label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="0911223344"
                        className="w-full pl-10 pr-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm font-mono text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">የይለፍ ቃል ፍጠር (Password - min 6)</label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                      <input
                        type="password"
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="ቢያንስ 6 ፊደላት ወይም ቁጥሮች"
                        className="w-full pl-10 pr-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>
                </>
              ) : (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">የቴሌብር ስልክ ቁጥር (Telebirr Phone)</label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="0911223344"
                      className="w-full pl-10 pr-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm font-mono text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 px-4 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-md shadow-amber-400/20 active:scale-[0.98] disabled:opacity-50"
              >
                <span>{loading ? 'በመመዝገብ ላይ...' : 'ተመዝገብና ግባ (Sign Up Now)'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            <div className="relative my-3 flex items-center justify-center">
              <div className="border-t border-slate-800 w-full" />
              <span className="bg-slate-900 px-3 text-[11px] text-slate-500 font-medium">ወይም (OR)</span>
            </div>

            <button
              type="button"
              onClick={handleGoogleLogin}
              disabled={loading}
              className="w-full py-2.5 px-4 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-white rounded-xl font-semibold text-xs flex items-center justify-center gap-3 transition-colors disabled:opacity-50"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>በ Google መለያ ተመዝገብ (Sign Up with Google)</span>
            </button>
          </div>
        )}

        {/* Footer info banner */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 flex items-center gap-2 text-[11px] text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            {authMode === 'login'
              ? 'አድሚን ከሆኑ በ mameboss98@gmail.com ሲገቡ የአድሚን ፓነሉ ይከፈትልዎታል።'
              : 'አዲስ አካውንት በ 0.00 ብር ይከፈታል፤ በቴሌብር እና ሲቢኢ ገንዘብ ማስገባት ይችላሉ።'}
          </span>
        </div>
      </div>
    </div>
  );
};
