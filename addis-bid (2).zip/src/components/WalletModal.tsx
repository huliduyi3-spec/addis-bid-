import React, { useState } from 'react';
import {
  X,
  Wallet,
  CheckCircle2,
  ShieldCheck,
  Smartphone,
  Building,
  Clock,
  Send,
  AlertCircle,
  Copy,
  Check,
} from 'lucide-react';
import { UserProfile, WalletTransaction, PaymentMethod } from '../types/auction';
import { formatETB, formatUSD } from '../utils/lubEngine';
import { addDoc, collection, doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../context/AuthContext';

interface WalletModalProps {
  user: UserProfile;
  currency: 'ETB' | 'USD';
  transactions: WalletTransaction[];
  onClose: () => void;
  onDeposit: (amount: number, method: PaymentMethod) => void;
}

export const WalletModal: React.FC<WalletModalProps> = ({
  user,
  currency,
  transactions,
  onClose,
  onDeposit,
}) => {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'deposit' | 'history'>('deposit');
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('telebirr');
  const [depositAmount, setDepositAmount] = useState<string>('500');
  const [senderPhone, setSenderPhone] = useState<string>(user.phone || '09');
  const [transactionId, setTransactionId] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submittedTx, setSubmittedTx] = useState<{ amount: number; txId: string } | null>(null);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Dynamic Payment Settings configured by Admin
  const [telebirrNumber, setTelebirrNumber] = useState<string>('0911 22 33 44');
  const [telebirrName, setTelebirrName] = useState<string>('Addis Bid Auctions');
  const [cbeAccount, setCbeAccount] = useState<string>('1000 4829 1928');
  const [cbeName, setCbeName] = useState<string>('Addis Bid General Trading');
  const [customInstructions, setCustomInstructions] = useState<string>('');

  React.useEffect(() => {
    const unsub = onSnapshot(doc(db, 'settings', 'payment'), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        if (data.telebirrNumber) setTelebirrNumber(data.telebirrNumber);
        if (data.telebirrName) setTelebirrName(data.telebirrName);
        if (data.cbeAccount) setCbeAccount(data.cbeAccount);
        if (data.cbeName) setCbeName(data.cbeName);
        if (data.instructions) setCustomInstructions(data.instructions);
      }
    });
    return () => unsub();
  }, []);

  const presets = [100, 250, 500, 1000, 2500, 5000];

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleSubmitDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(depositAmount);
    if (isNaN(amt) || amt < 10) {
      alert('Please enter a minimum deposit of 10 ETB');
      return;
    }

    if (!transactionId.trim()) {
      alert('Please enter your Telebirr / CBE Transaction ID from the SMS');
      return;
    }

    setIsSubmitting(true);
    try {
      if (currentUser) {
        // Record in Firestore for Admin Approval
        await addDoc(collection(db, 'deposits'), {
          userId: currentUser.uid,
          userEmail: currentUser.email || 'user@addisbid.et',
          userName: user.name,
          amount: amt,
          method: selectedMethod,
          transactionId: transactionId.trim().toUpperCase(),
          phoneNumber: senderPhone.trim(),
          status: 'pending',
          createdAt: new Date().toISOString(),
        });
      }

      setSubmittedTx({ amount: amt, txId: transactionId.trim().toUpperCase() });
      setTransactionId('');
    } catch (err) {
      console.error('Failed to submit deposit:', err);
      // Fallback local update
      onDeposit(amt, selectedMethod);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col relative my-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-6 border-b border-slate-800 sticky top-0 bg-slate-900/95 backdrop-blur z-20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-400/10 border border-amber-400/30 flex items-center justify-center text-amber-400">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span>ADDIS WALLET</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-400 font-semibold">TELEBIRR & CBE BIRR</span>
              </div>
              <h2 className="font-display font-bold text-lg sm:text-xl text-white tracking-tight">
                Deposit Bidding Funds
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Balance Card */}
        <div className="p-6 bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/30 border-b border-slate-800">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                Current Wallet Balance
              </span>
              <div className="text-3xl sm:text-4xl font-display font-extrabold text-white tabular-nums mt-1">
                {currency === 'ETB' ? formatETB(user.walletBalanceETB) : formatUSD(user.walletBalanceETB / 130)}
              </div>
              <div className="text-xs text-slate-400 mt-1">
                Account Holder: <span className="text-slate-200 font-medium">{user.name}</span>
              </div>
            </div>

            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 text-xs space-y-1">
              <div className="flex justify-between gap-4 text-slate-400">
                <span>Active Bids:</span>
                <span className="font-mono text-white font-bold">{user.totalBidsPlaced}</span>
              </div>
              <div className="flex justify-between gap-4 text-slate-400">
                <span>Lots Won:</span>
                <span className="font-mono text-amber-400 font-bold">{user.winsCount}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="p-4 sm:p-6 pb-0">
          <div className="flex items-center gap-2 p-1 bg-slate-950 border border-slate-800 rounded-lg text-xs">
            <button
              onClick={() => setActiveTab('deposit')}
              className={`flex-1 py-2 rounded-md font-semibold transition-colors ${
                activeTab === 'deposit'
                  ? 'bg-amber-400 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Deposit via Telebirr / Bank
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`flex-1 py-2 rounded-md font-semibold transition-colors ${
                activeTab === 'history'
                  ? 'bg-amber-400 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Recent Transactions
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-6 space-y-6">
          {activeTab === 'deposit' ? (
            <div className="space-y-6">
              {submittedTx && (
                <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-600/60 text-amber-200 text-xs space-y-2">
                  <div className="flex items-center gap-2 font-bold text-sm text-amber-400">
                    <Clock className="w-4 h-4" />
                    <span>Deposit of {formatETB(submittedTx.amount)} Submitted for Verification!</span>
                  </div>
                  <div className="text-slate-300">
                    Transaction ID: <span className="font-mono text-white font-bold">{submittedTx.txId}</span>
                  </div>
                  <div className="text-[11px] text-slate-400">
                    The platform admin will verify the transfer in the Telebirr system and approve your balance within minutes.
                  </div>
                </div>
              )}

              {/* Payment Methods */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2.5">
                  1. Select Official Payment Method
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setSelectedMethod('telebirr')}
                    className={`p-3.5 rounded-xl border text-left transition-all flex items-center gap-3 ${
                      selectedMethod === 'telebirr'
                        ? 'bg-amber-400/10 border-amber-400 text-white shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="w-9 h-9 rounded-lg bg-amber-400/20 text-amber-400 flex items-center justify-center shrink-0">
                      <Smartphone className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-bold text-sm text-white">telebirr</div>
                      <div className="text-[11px] text-slate-400">Instant Mobile Money</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedMethod('cbe')}
                    className={`p-3.5 rounded-xl border text-left transition-all flex items-center gap-3 ${
                      selectedMethod === 'cbe'
                        ? 'bg-amber-400/10 border-amber-400 text-white shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="w-9 h-9 rounded-lg bg-emerald-400/20 text-emerald-400 flex items-center justify-center shrink-0">
                      <Building className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-bold text-sm text-white">CBE / CBE Birr</div>
                      <div className="text-[11px] text-slate-400">Commercial Bank Transfer</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Payment Destination Details */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  <span>Send Money to this Official Account</span>
                </div>

                {selectedMethod === 'telebirr' ? (
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-slate-900 rounded-lg border border-slate-800/80">
                    <div>
                      <div className="text-xs text-slate-400">Telebirr Account Number</div>
                      <div className="text-base font-mono font-bold text-emerald-400">{telebirrNumber}</div>
                      <div className="text-[11px] text-slate-300">Recipient: <strong className="text-white">{telebirrName}</strong></div>
                    </div>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(telebirrNumber)}
                      className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white flex items-center gap-1.5 self-start sm:self-auto transition-colors"
                    >
                      {copiedText === telebirrNumber ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedText === telebirrNumber ? 'Copied' : 'Copy Number'}</span>
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-slate-900 rounded-lg border border-slate-800/80">
                    <div>
                      <div className="text-xs text-slate-400">Commercial Bank of Ethiopia (CBE)</div>
                      <div className="text-base font-mono font-bold text-amber-400">{cbeAccount}</div>
                      <div className="text-[11px] text-slate-300">Recipient: <strong className="text-white">{cbeName}</strong></div>
                    </div>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(cbeAccount)}
                      className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white flex items-center gap-1.5 self-start sm:self-auto transition-colors"
                    >
                      {copiedText === cbeAccount ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedText === cbeAccount ? 'Copied' : 'Copy Account'}</span>
                    </button>
                  </div>
                )}

                {customInstructions && (
                  <div className="text-xs text-amber-300/90 bg-amber-950/30 p-2.5 rounded-lg border border-amber-900/50">
                    ℹ️ {customInstructions}
                  </div>
                )}
              </div>

              {/* Deposit Form */}
              <form onSubmit={handleSubmitDeposit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                    2. Amount to Deposit (ETB)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min="10"
                      step="1"
                      required
                      value={depositAmount}
                      onChange={(e) => setDepositAmount(e.target.value)}
                      className="w-full pl-4 pr-16 py-3 bg-slate-950 border border-slate-800 rounded-xl text-lg font-mono font-bold text-white focus:outline-none focus:border-amber-400"
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-mono text-amber-400 font-bold">
                      ETB
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-2 mt-2">
                    {presets.map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setDepositAmount(preset.toString())}
                        className={`px-3 py-1 text-xs font-mono font-semibold rounded-lg border transition-colors ${
                          depositAmount === preset.toString()
                            ? 'bg-amber-400 text-slate-950 border-amber-400'
                            : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        +{preset} ETB
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                      Your Sender Phone Number
                    </label>
                    <input
                      type="tel"
                      required
                      value={senderPhone}
                      onChange={(e) => setSenderPhone(e.target.value)}
                      placeholder="0911223344"
                      className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm font-mono text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                      SMS Transaction ID / Ref No.
                    </label>
                    <input
                      type="text"
                      required
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value)}
                      placeholder="e.g. TLB893120ET"
                      className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm font-mono uppercase text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-display font-extrabold text-sm rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition-all disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{isSubmitting ? 'Submitting to Ledger...' : `Confirm Deposit of ${depositAmount ? formatETB(parseFloat(depositAmount) || 0) : '0 ETB'}`}</span>
                </button>
              </form>
            </div>
          ) : (
            /* History Tab */
            <div className="space-y-3">
              {transactions.length === 0 ? (
                <div className="py-12 text-center text-slate-500 text-xs">
                  No transactions on record yet.
                </div>
              ) : (
                transactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-4"
                  >
                    <div>
                      <div className="font-semibold text-xs text-white">{tx.description}</div>
                      <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                        Ref: {tx.referenceId} · {new Date(tx.timestamp).toLocaleDateString()}
                      </div>
                    </div>
                    <div
                      className={`font-mono font-bold text-xs ${
                        tx.type === 'deposit' ? 'text-emerald-400' : 'text-slate-300'
                      }`}
                    >
                      {tx.type === 'deposit' ? '+' : '-'}
                      {formatETB(tx.amountETB)}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
