import React from 'react';
import { ArrowDown, Play, ShieldCheck, Zap, Coins } from 'lucide-react';
import { AuctionItem } from '../types/auction';
import { formatETB, formatUSD } from '../utils/lubEngine';

interface HeroBannerProps {
  featuredItem: AuctionItem;
  currency: 'ETB' | 'USD';
  onSelectAuction: (item: AuctionItem) => void;
  onOpenSandbox: () => void;
  onOpenHowItWorks: () => void;
  onOpenAuth?: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  featuredItem,
  currency,
  onSelectAuction,
  onOpenSandbox,
  onOpenHowItWorks,
  onOpenAuth,
}) => {
  return (
    <section className="relative overflow-hidden border-b border-slate-800/80 bg-slate-950">
      {/* Background Image with Scrim Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/hero_addis_auction_1793560375390.jpg"
          alt="Addis Bid Luxury Showroom"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-slate-950/40" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-16 lg:pt-16 lg:pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column: Hero Headline & Value Proposition */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            {/* Quiet text kicker per Zero-Pill discipline */}
            <div className="flex items-center gap-2 text-xs font-medium text-amber-400 mb-4 tracking-wide">
              <span>ADDIS ABABA PREMIER AUCTION</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="text-slate-400">PATENTED LOWEST UNIQUE ALGORITHM</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-extrabold text-white tracking-tight leading-[1.08] [text-wrap:balance]">
              The Lowest <span className="text-amber-400">Unique Price</span> Wins.
            </h1>

            <p className="mt-5 text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl">
              Unlike traditional auctions where the highest spender wins, Addis Bid introduces a strategic game-theory breakthrough: Place your secret price. If no one else bids your exact amount, the absolute lowest unique bid claims the prize.
            </p>


            {/* CTAs */}
            <div className="mt-6 flex flex-wrap items-center gap-3 sm:gap-4">
              <button
                onClick={() => {
                  const el = document.getElementById('auctions-section');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="flex items-center gap-2 px-6 py-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-semibold text-sm transition-all shadow-md shadow-amber-400/20 active:scale-[0.98] whitespace-nowrap"
              >
                <span>Browse Live Auctions</span>
                <ArrowDown className="w-4 h-4" />
              </button>

              {onOpenAuth && (
                <button
                  onClick={onOpenAuth}
                  className="flex items-center gap-2 px-5 py-3 rounded-lg border border-amber-400/50 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 font-bold text-sm transition-all whitespace-nowrap shadow-sm shadow-amber-500/10"
                >
                  <span>✨ ተመዝገብ / ግባ (Sign Up)</span>
                </button>
              )}

              <button
                onClick={onOpenSandbox}
                className="flex items-center gap-2 px-5 py-3 rounded-lg border border-slate-700 bg-slate-900/80 hover:bg-slate-800 text-white font-medium text-sm transition-colors whitespace-nowrap"
              >
                <Play className="w-4 h-4 text-amber-400" />
                <span>Test Simulator</span>
              </button>

              <button
                onClick={onOpenHowItWorks}
                className="text-xs text-slate-400 hover:text-slate-200 transition-colors underline underline-offset-4"
              >
                Read Game Rules
              </button>
            </div>

            {/* Trust Markers */}
            <div className="mt-10 pt-6 border-t border-slate-800/80 flex flex-wrap items-center gap-6 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Verifiable SHA-256 Fairness Audit</span>
              </div>
              <span aria-hidden="true" className="text-slate-700 hidden sm:inline">·</span>
              <div className="flex items-center gap-2">
                <Coins className="w-4 h-4 text-amber-400 shrink-0" />
                <span>telebirr & CBE Birr Instant Wallet</span>
              </div>
              <span aria-hidden="true" className="text-slate-700 hidden sm:inline">·</span>
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Up to 99% Retail Savings</span>
              </div>
            </div>
          </div>

          {/* Right Column: Featured Live Spotlight Card */}
          <div className="lg:col-span-5">
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-2xl relative overflow-hidden group">
              <div className="text-xs text-slate-400 flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-amber-400">FEATURED SPOTLIGHT</span>
                  <span aria-hidden="true">·</span>
                  <span>{featuredItem.category.toUpperCase()}</span>
                </div>
                <span className="font-mono text-emerald-400 text-xs">● Live Bidding Open</span>
              </div>

              {/* Spotlight Image Container */}
              <div className="relative aspect-[4/3] rounded-lg overflow-hidden bg-slate-950 mb-4">
                <img
                  src={featuredItem.image}
                  alt={featuredItem.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3 bg-slate-950/85 backdrop-blur-sm border border-slate-800 px-2.5 py-1 rounded text-xs text-white">
                  <span className="text-slate-400 mr-1.5">Value:</span>
                  <span className="font-mono font-semibold tabular-nums text-amber-300">
                    {currency === 'ETB' ? formatETB(featuredItem.retailValueETB) : formatUSD(featuredItem.retailValueUSD)}
                  </span>
                </div>
              </div>

              <h3 className="font-display font-bold text-lg text-white tracking-tight">
                {featuredItem.title}
              </h3>
              <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                {featuredItem.subtitle}
              </p>

              {/* Key Auction Metrics */}
              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="text-slate-500">Current Secret Bids</div>
                  <div className="text-sm font-mono font-bold text-white tabular-nums mt-0.5">
                    {featuredItem.totalBidsCount} bids sealed
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-slate-500">Entry Per Bid</div>
                  <div className="text-sm font-mono font-bold text-amber-400 tabular-nums mt-0.5">
                    {formatETB(featuredItem.entryFeeETB)}
                  </div>
                </div>
              </div>

              <button
                onClick={() => onSelectAuction(featuredItem)}
                className="mt-4 w-full py-2.5 px-4 bg-amber-400 hover:bg-amber-300 text-slate-950 font-semibold text-xs rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <span>Enter Secret Bid on This Lot</span>
              </button>
            </div>
          </div>
        </div>

        {/* 3-Step Strategy Explainer Strip */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-3 gap-6 pt-8 border-t border-slate-800/80">
          <div className="flex flex-col">
            <span className="text-xs font-mono text-amber-400 font-semibold mb-1">01. Secret Entry</span>
            <h4 className="text-sm font-semibold text-white">Submit Your Sealed Price</h4>
            <p className="mt-1.5 text-xs text-slate-400 leading-relaxed">
              Choose an unconventional, realistic low price (e.g. 3.42 ETB). Your bid remains secret and protected from competitor view.
            </p>
          </div>

          <div className="flex flex-col">
            <span className="text-xs font-mono text-amber-400 font-semibold mb-1">02. Duplicate Collision</span>
            <h4 className="text-sm font-semibold text-white">Identical Bids Cancel Out</h4>
            <p className="mt-1.5 text-xs text-slate-400 leading-relaxed">
              If another bidder places the exact same number, both bids are cancelled out. Avoid obvious numbers like 0.01 or round numbers!
            </p>
          </div>

          <div className="flex flex-col">
            <span className="text-xs font-mono text-amber-400 font-semibold mb-1">03. Lowest Unique Wins</span>
            <h4 className="text-sm font-semibold text-white">Take Home The Item</h4>
            <p className="mt-1.5 text-xs text-slate-400 leading-relaxed">
              When the timer expires, the person with the lowest non-repeated bid pays their submitted amount and claims the prize!
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
