import React, { useState, useEffect } from 'react';
import { Search, Trophy, ShieldCheck, Sparkles, Filter, Award, CheckCircle2, ChevronRight, AlertTriangle, Shield, User, Wallet } from 'lucide-react';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { AuctionCard } from './components/AuctionCard';
import { AuctionDetailModal } from './components/AuctionDetailModal';
import { AuctionResultModal } from './components/AuctionResultModal';
import { HowItWorksModal } from './components/HowItWorksModal';
import { StrategySandbox } from './components/StrategySandbox';
import { WalletModal } from './components/WalletModal';
import { MyBidsModal } from './components/MyBidsModal';
import { ClaimPrizeModal } from './components/ClaimPrizeModal';
import { NotificationsPopover } from './components/NotificationsPopover';
import { AuthModal } from './components/AuthModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { AuthProvider, useAuth } from './context/AuthContext';
import { MOCK_AUCTIONS } from './data/mockAuctions';
import {
  AuctionItem,
  UserProfile,
  UserBid,
  WalletTransaction,
  AppNotification,
  AuctionCategory,
  PaymentMethod,
} from './types/auction';
import { analyzeLUB, formatETB, formatUSD, getBidStatus, SAMPLE_BIDDER_NAMES } from './utils/lubEngine';
import {
  doc,
  updateDoc,
  collection,
  addDoc,
  onSnapshot,
  query,
  where,
  setDoc,
  deleteDoc,
} from 'firebase/firestore';
import { db } from './firebase';

function AppContent() {
  const { currentUser, userProfile, isAdmin } = useAuth();

  const [auctions, setAuctions] = useState<AuctionItem[]>(MOCK_AUCTIONS);
  const [currency, setCurrency] = useState<'ETB' | 'USD'>('ETB');

  // Real-time synchronization for auctions from Firestore
  useEffect(() => {
    try {
      const unsub = onSnapshot(collection(db, 'auctions'), (snap) => {
        if (!snap.empty) {
          const list: AuctionItem[] = [];
          snap.forEach((d) => {
            list.push({ id: d.id, ...(d.data() as any) });
          });
          // Sort ending soon first
          list.sort((a, b) => a.endTime - b.endTime);
          setAuctions(list);
        }
      });
      return () => unsub();
    } catch (err) {
      console.error('Firestore auctions listener error:', err);
    }
  }, []);

  const handleSaveAuction = async (item: AuctionItem) => {
    try {
      await setDoc(doc(db, 'auctions', item.id), item, { merge: true });
      setAuctions((prev) => {
        const idx = prev.findIndex((a) => a.id === item.id);
        if (idx >= 0) {
          const updated = [...prev];
          updated[idx] = item;
          return updated;
        } else {
          return [item, ...prev];
        }
      });
    } catch (err) {
      console.error('Failed to save auction in firestore, updating locally:', err);
      setAuctions((prev) => {
        const idx = prev.findIndex((a) => a.id === item.id);
        if (idx >= 0) {
          const updated = [...prev];
          updated[idx] = item;
          return updated;
        } else {
          return [item, ...prev];
        }
      });
    }
  };

  const handleDeleteAuction = async (auctionId: string) => {
    try {
      await deleteDoc(doc(db, 'auctions', auctionId));
      setAuctions((prev) => prev.filter((a) => a.id !== auctionId));
    } catch (err) {
      console.error('Failed to delete auction from firestore, updating locally:', err);
      setAuctions((prev) => prev.filter((a) => a.id !== auctionId));
    }
  };

  // Real or Guest User Profile: Starts with 0.00 ETB for clean official experience
  const activeUser: UserProfile = userProfile || {
    id: currentUser?.uid || 'guest-user',
    name: currentUser?.displayName || 'Guest Bidder',
    email: currentUser?.email || '',
    phone: '+251 911 000 000',
    walletBalanceETB: 0, // 0 ETB balance by default
    totalBidsPlaced: 0,
    winsCount: 0,
    avatar: currentUser?.photoURL || undefined,
  };

  // User bids state
  const [userBids, setUserBids] = useState<UserBid[]>([]);
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([
    {
      id: 'notif-welcome',
      title: 'እንኳን ወደ አዲስ ቢድ በደህና መጡ! (Welcome)',
      message: 'ይህ እውነተኛ የቴሌብር እና ሲቢኢ ጨረታ ነው። በቴሌብር ዲፖዚት በማድረግ በትንሽ ክፍያ ትላልቅ እቃዎችን በዝቅተኛ ዋጋ ያሸንፉ!',
      timestamp: Date.now(),
      read: false,
      type: 'system',
    },
  ]);

  // Modal States
  const [selectedAuction, setSelectedAuction] = useState<AuctionItem | null>(null);
  const [auditAuction, setAuditAuction] = useState<AuctionItem | null>(null);
  const [claimAuction, setClaimAuction] = useState<AuctionItem | null>(null);
  const [isWalletOpen, setIsWalletOpen] = useState<boolean>(false);
  const [isHowItWorksOpen, setIsHowItWorksOpen] = useState<boolean>(false);
  const [isSandboxOpen, setIsSandboxOpen] = useState<boolean>(false);
  const [isMyBidsOpen, setIsMyBidsOpen] = useState<boolean>(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState<boolean>(false);

  // Filters & Search
  const [categoryFilter, setCategoryFilter] = useState<AuctionCategory>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'ending_soon' | 'value_high' | 'bids_high'>('ending_soon');
  const [activeNavTab, setActiveNavTab] = useState<string>('auctions');

  // Listen to User Deposits from Firestore
  useEffect(() => {
    if (!currentUser) return;

    try {
      const depositsQuery = query(
        collection(db, 'deposits'),
        where('userId', '==', currentUser.uid)
      );
      const unsub = onSnapshot(depositsQuery, (snap) => {
        const txs: WalletTransaction[] = [];
        snap.forEach((d) => {
          const data = d.data();
          txs.push({
            id: d.id,
            type: 'deposit',
            method: (data.method || 'telebirr') as PaymentMethod,
            amountETB: data.amount,
            description: `${(data.method || 'telebirr').toUpperCase()} Transfer (${data.status === 'approved' ? 'Approved' : 'Pending'})`,
            timestamp: new Date(data.createdAt).getTime(),
            referenceId: data.transactionId || 'TLB-TX',
            status: data.status === 'approved' ? 'completed' : data.status === 'rejected' ? 'failed' : 'pending',
          });
        });
        txs.sort((a, b) => b.timestamp - a.timestamp);
        setTransactions(txs);
      });

      return () => unsub();
    } catch (e) {
      console.warn('Deposits listener:', e);
    }
  }, [currentUser]);

  // Handler: Place a single secret bid
  const handlePlaceBid = async (auctionId: string, amount: number): Promise<boolean> => {
    // 1. Must be logged in
    if (!currentUser) {
      setIsAuthOpen(true);
      return false;
    }

    const target = auctions.find((a) => a.id === auctionId);
    if (!target) return false;

    // 2. Check real wallet balance
    if (activeUser.walletBalanceETB < target.entryFeeETB) {
      setIsWalletOpen(true);
      return false;
    }

    const newBidRecord = {
      id: `bid-usr-${Date.now()}`,
      userId: currentUser.uid,
      userName: activeUser.name,
      amount,
      timestamp: Date.now(),
      isUser: true,
    };

    const updatedBids = [...target.bids, newBidRecord];
    const status = getBidStatus(amount, updatedBids);

    // Deduct entry fee in Firestore if user is authenticated
    try {
      const userDocRef = doc(db, 'users', currentUser.uid);
      const nextBalance = Math.max(0, activeUser.walletBalanceETB - target.entryFeeETB);
      await updateDoc(userDocRef, {
        balance: nextBalance,
        totalBidsPlaced: activeUser.totalBidsPlaced + 1,
      });

      // Record bid in Firestore
      await addDoc(collection(db, 'auctions', auctionId, 'bids'), {
        userId: currentUser.uid,
        userName: activeUser.name,
        auctionId,
        amount,
        createdAt: new Date().toISOString(),
      });
    } catch (err) {
      console.warn('Bid synced locally:', err);
    }

    // Update auction locally
    setAuctions((prev) =>
      prev.map((a) =>
        a.id === auctionId
          ? { ...a, bids: updatedBids, totalBidsCount: updatedBids.length }
          : a
      )
    );

    // Record user bid
    const newBid: UserBid = {
      id: `ub-${Date.now()}`,
      auctionId,
      auctionTitle: target.title,
      auctionImage: target.image,
      amount,
      feePaidETB: target.entryFeeETB,
      placedAt: Date.now(),
      status,
    };
    setUserBids((prev) => [newBid, ...prev]);

    // Record wallet transaction
    const newTx: WalletTransaction = {
      id: `tx-${Date.now()}`,
      type: 'bid_fee',
      amountETB: target.entryFeeETB,
      description: `Secret Bid Entry (${target.title})`,
      timestamp: Date.now(),
      referenceId: `FEE-${Math.floor(100000 + Math.random() * 900000)}`,
      status: 'completed',
    };
    setTransactions((prev) => [newTx, ...prev]);

    // Send status notification
    if (status === 'unique_lowest') {
      const notif: AppNotification = {
        id: `notif-${Date.now()}`,
        title: '🌟 Leading Position!',
        message: `Your bid of ${formatETB(amount)} is currently the lowest unique bid on ${target.title}!`,
        timestamp: Date.now(),
        read: false,
        type: 'unique_alert',
        auctionId,
      };
      setNotifications((n) => [notif, ...n]);
    } else if (status === 'duplicated') {
      const notif: AppNotification = {
        id: `notif-${Date.now()}`,
        title: '⚠️ Duplicate Collision Alert',
        message: `Your bid of ${formatETB(amount)} was already placed by another bidder. It is currently cancelled out.`,
        timestamp: Date.now(),
        read: false,
        type: 'duplicate_alert',
        auctionId,
      };
      setNotifications((n) => [notif, ...n]);
    }

    return true;
  };

  // Handler: Place 3x strategic spread bids
  const handlePlaceSpreadBids = (auctionId: string, amounts: number[]) => {
    amounts.forEach((amt) => {
      handlePlaceBid(auctionId, amt);
    });
  };

  // Handler: Deposit funds fallback
  const handleDeposit = (amount: number, method: PaymentMethod) => {
    const newTx: WalletTransaction = {
      id: `tx-${Date.now()}`,
      type: 'deposit',
      method,
      amountETB: amount,
      description: `${method.toUpperCase()} Mobile Deposit (Pending Approval)`,
      timestamp: Date.now(),
      referenceId: `${method.slice(0, 3).toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}-ET`,
      status: 'pending',
    };
    setTransactions((prev) => [newTx, ...prev]);

    const notif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: 'ዲፖዚት ተልኳል (Deposit Submitted)',
      message: `${formatETB(amount)} በቴሌብር የላኩት ጥያቄ ለአድሚን ደርሷል። ማረጋገጫ ሲያገኝ ወደ አካውንትዎ ገቢ ይሆናል።`,
      timestamp: Date.now(),
      read: false,
      type: 'deposit',
    };
    setNotifications((prev) => [notif, ...prev]);
  };

  // Filtered & Sorted Auctions
  const filteredAuctions = auctions.filter((auc) => {
    const matchesCategory = categoryFilter === 'all' || auc.category === categoryFilter;
    const matchesSearch =
      auc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      auc.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      auc.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const sortedAuctions = [...filteredAuctions].sort((a, b) => {
    if (sortBy === 'ending_soon') {
      if (a.status === 'completed') return 1;
      if (b.status === 'completed') return -1;
      return a.endTime - b.endTime;
    }
    if (sortBy === 'value_high') {
      return b.retailValueETB - a.retailValueETB;
    }
    if (sortBy === 'bids_high') {
      return b.totalBidsCount - a.totalBidsCount;
    }
    return 0;
  });

  const featuredItem = auctions[0];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500/30 pb-16 lg:pb-0">
      {/* 1. Header / Navbar */}
      <Navbar
        user={activeUser}
        currency={currency}
        onToggleCurrency={() => setCurrency((c) => (c === 'ETB' ? 'USD' : 'ETB'))}
        notifications={notifications}
        onOpenWallet={() => setIsWalletOpen(true)}
        onOpenMyBids={() => setIsMyBidsOpen(true)}
        onOpenHowItWorks={() => setIsHowItWorksOpen(true)}
        onOpenSandbox={() => setIsSandboxOpen(true)}
        onOpenWinners={() => {
          const completedLot = auctions.find((a) => a.status === 'completed') || auctions[0];
          setAuditAuction(completedLot);
        }}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onOpenAdmin={() => setIsAdminPanelOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        activeNavTab={activeNavTab}
        setActiveNavTab={setActiveNavTab}
      />

      {/* Admin Notice Banner if logged in as Admin */}
      {isAdmin && (
        <div className="bg-amber-500/15 border-b border-amber-500/30 px-4 py-2 text-center text-xs text-amber-300 flex items-center justify-center gap-2">
          <Shield className="w-4 h-4 text-amber-400" />
          <span>
            <strong>የአድሚን አካውንት ገብቷል:</strong> mameboss98@gmail.com — የቴሌብር ዲፖዚቶችን ለማጽደቅ «Admin Panel» ቁልፍን ይጫኑ።
          </span>
          <button
            onClick={() => setIsAdminPanelOpen(true)}
            className="underline font-bold text-amber-400 hover:text-white ml-2"
          >
            ክፈት
          </button>
        </div>
      )}

      {/* 2. Hero Section */}
      <HeroBanner
        featuredItem={featuredItem}
        currency={currency}
        onSelectAuction={(item) => setSelectedAuction(item)}
        onOpenSandbox={() => setIsSandboxOpen(true)}
        onOpenHowItWorks={() => setIsHowItWorksOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
      />

      {/* 3. Main Catalog Section */}
      <main id="auctions-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-1 w-full">
        {/* Section Heading & Category Tabs */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold mb-1">
              <span>EXPLORE LOTS</span>
              <span aria-hidden="true">·</span>
              <span className="text-slate-400">SECRET REVERSE AUCTIONS</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-display font-extrabold text-white tracking-tight">
              የጨረታ እቃዎች ዝርዝር (Active Lots)
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              በቴሌብር ወይም በባንክ ተወዳድረው እቃዎችን በዝቅተኛ ያልተደገመ ዋጋ (Lowest Unique Bid) ያሸንፉ!
            </p>
          </div>

          {/* Interactive Filter Segmented Controls */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-lg overflow-x-auto">
            {(['all', 'vehicles', 'smartphones', 'laptops', 'gaming'] as AuctionCategory[]).map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md whitespace-nowrap transition-colors capitalize ${
                  categoryFilter === cat
                    ? 'bg-amber-400 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {cat === 'all' ? 'All Lots' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Search & Sort Sub-Toolbar */}
        <div className="py-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by brand, vehicle, or electronics..."
              className="w-full pl-9 pr-4 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="flex items-center gap-3 text-xs self-end sm:self-auto">
            <span className="text-slate-500">Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white font-medium focus:outline-none focus:border-amber-400"
            >
              <option value="ending_soon">Ending Soon</option>
              <option value="value_high">Highest Retail Value</option>
              <option value="bids_high">Most Active Bids</option>
            </select>
          </div>
        </div>

        {/* 3-Column Product Grid */}
        {sortedAuctions.length === 0 ? (
          <div className="py-20 text-center text-slate-500 text-xs">
            No auction lots found matching your filter criteria. Try clearing search or selecting "All Lots".
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {sortedAuctions.map((item) => (
              <AuctionCard
                key={item.id}
                item={item}
                currency={currency}
                userBidsOnItem={userBids.filter((b) => b.auctionId === item.id)}
                onSelect={(selected) => setSelectedAuction(selected)}
                onOpenAudit={(completed) => setAuditAuction(completed)}
              />
            ))}
          </div>
        )}

        {/* Recent Winners & Proof Section */}
        <section className="mt-20 pt-12 border-t border-slate-800/80">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 mb-1">
                <span>VERIFIABLE RESULTS</span>
                <span aria-hidden="true">·</span>
                <span className="text-slate-400">TRANSPARENT WINNERS</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-display font-bold text-white tracking-tight">
                ያለፉት አሸናፊዎች (Recent Winners)
              </h3>
            </div>
            <button
              onClick={() => {
                const completedLot = auctions.find((a) => a.status === 'completed') || auctions[0];
                setAuditAuction(completedLot);
              }}
              className="text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 self-start sm:self-auto"
            >
              <span>View Full Cryptographic Audit</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">DJI Mini 4 Pro Drone Kit</span>
                <span className="font-mono text-emerald-400 font-bold text-xs">99.98% Saved</span>
              </div>
              <div className="text-lg font-display font-bold text-white">
                Won for <span className="font-mono text-amber-400">4.17 ETB</span>
              </div>
              <div className="text-xs text-slate-400">
                Champion: <strong className="text-white">Dawit M.</strong> (Bole, Addis Ababa)
              </div>
              <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-500 font-mono">
                SHA-256 Commit: sha256-91b72e...
              </div>
            </div>

            <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">Samsung S24 Ultra 512GB</span>
                <span className="font-mono text-emerald-400 font-bold text-xs">99.94% Saved</span>
              </div>
              <div className="text-lg font-display font-bold text-white">
                Won for <span className="font-mono text-amber-400">8.92 ETB</span>
              </div>
              <div className="text-xs text-slate-400">
                Champion: <strong className="text-white">Bethlehem A.</strong> (Kazanchis)
              </div>
              <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-500 font-mono">
                SHA-256 Commit: sha256-4c810d...
              </div>
            </div>

            <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">Sony Alpha 7 IV Camera</span>
                <span className="font-mono text-emerald-400 font-bold text-xs">99.96% Saved</span>
              </div>
              <div className="text-lg font-display font-bold text-white">
                Won for <span className="font-mono text-amber-400">6.35 ETB</span>
              </div>
              <div className="text-xs text-slate-400">
                Champion: <strong className="text-white">Yonas T.</strong> (Sarbet)
              </div>
              <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-500 font-mono">
                SHA-256 Commit: sha256-a19e44...
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* 4. Footer */}
      <footer className="mt-auto border-t border-slate-800/80 bg-slate-950 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div className="space-y-3">
              <span className="font-display font-extrabold text-lg text-white">
                ADDIS<span className="text-amber-400">BID</span>
              </span>
              <p className="text-xs text-slate-400 leading-relaxed">
                Addis Ababa’s premier lowest unique price reverse auction platform. All products are authentic with official manufacturer warranties and transparent cryptographic auditing.
              </p>
            </div>

            <div>
              <h5 className="text-xs font-semibold uppercase text-slate-300 tracking-wider mb-3">
                Platform Rules
              </h5>
              <ul className="space-y-2 text-xs text-slate-400">
                <li>
                  <button onClick={() => setIsHowItWorksOpen(true)} className="hover:text-white transition-colors">
                    Lowest Unique Bid Rules
                  </button>
                </li>
                <li>
                  <button onClick={() => setIsSandboxOpen(true)} className="hover:text-white transition-colors">
                    Game Theory Simulator
                  </button>
                </li>
                <li>
                  <button onClick={() => setIsWalletOpen(true)} className="hover:text-white transition-colors">
                    telebirr & CBE Birr Deposits
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <h5 className="text-xs font-semibold uppercase text-slate-300 tracking-wider mb-3">
                Security & Compliance
              </h5>
              <ul className="space-y-2 text-xs text-slate-400">
                <li>Deterministic SHA-256 Hashes</li>
                <li>Fair-Play Verification Ledger</li>
                <li>Authorized Ethiopian Distributor Partners</li>
                <li>Bole Medhanialem Logistics Centre</li>
              </ul>
            </div>

            <div>
              <h5 className="text-xs font-semibold uppercase text-slate-300 tracking-wider mb-3">
                Payment Partners
              </h5>
              <div className="flex flex-wrap gap-2 text-[11px] font-mono text-slate-400">
                <span className="px-2 py-1 bg-slate-900 border border-slate-800 rounded text-amber-400 font-semibold">telebirr</span>
                <span className="px-2 py-1 bg-slate-900 border border-slate-800 rounded text-purple-400 font-semibold">CBE Birr</span>
                <span className="px-2 py-1 bg-slate-900 border border-slate-800 rounded">Chapa</span>
                <span className="px-2 py-1 bg-slate-900 border border-slate-800 rounded">Bank Transfer</span>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-800/60 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
            <div>© {new Date().getFullYear()} Addis Bid Technologies PLC. All rights reserved. Addis Ababa, Ethiopia.</div>
            <div className="flex items-center gap-4">
              <span>Privacy Policy</span>
              <span aria-hidden="true">·</span>
              <span>Terms of Participation</span>
              <span aria-hidden="true">·</span>
              <span>Fairness Pledge</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Modals & Overlays */}
      {selectedAuction && (
        <AuctionDetailModal
          item={selectedAuction}
          user={activeUser}
          currency={currency}
          userBidsOnItem={userBids.filter((b) => b.auctionId === selectedAuction.id)}
          onClose={() => setSelectedAuction(null)}
          onPlaceBid={handlePlaceBid}
          onPlaceSpreadBids={handlePlaceSpreadBids}
          onOpenWallet={() => {
            setSelectedAuction(null);
            setIsWalletOpen(true);
          }}
        />
      )}

      {auditAuction && (
        <AuctionResultModal
          item={auditAuction}
          currency={currency}
          onClose={() => setAuditAuction(null)}
          onClaimPrize={() => {
            setClaimAuction(auditAuction);
            setAuditAuction(null);
          }}
          isUserWinner={auditAuction.winningBid?.userId === activeUser.id}
        />
      )}

      {claimAuction && (
        <ClaimPrizeModal
          item={claimAuction}
          user={activeUser}
          winningAmount={claimAuction.winningBid?.amount || 4.17}
          onClose={() => setClaimAuction(null)}
          onSuccess={() => {}}
        />
      )}

      {isHowItWorksOpen && (
        <HowItWorksModal
          onClose={() => setIsHowItWorksOpen(false)}
          onOpenSandbox={() => setIsSandboxOpen(true)}
        />
      )}

      {isSandboxOpen && (
        <StrategySandbox onClose={() => setIsSandboxOpen(false)} />
      )}

      {isWalletOpen && (
        <WalletModal
          user={activeUser}
          currency={currency}
          transactions={transactions}
          onClose={() => setIsWalletOpen(false)}
          onDeposit={handleDeposit}
        />
      )}

      {isMyBidsOpen && (
        <MyBidsModal
          bids={userBids}
          auctions={auctions}
          onClose={() => setIsMyBidsOpen(false)}
          onSelectAuction={(lot) => {
            setIsMyBidsOpen(false);
            setSelectedAuction(lot);
          }}
          onClaimPrize={(lot) => {
            setIsMyBidsOpen(false);
            setClaimAuction(lot);
          }}
        />
      )}

      {isNotificationsOpen && (
        <NotificationsPopover
          notifications={notifications}
          onClose={() => setIsNotificationsOpen(false)}
          onMarkAllAsRead={() => {
            setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
          }}
          onNotificationClick={(notif) => {
            setNotifications((prev) =>
              prev.map((n) => (n.id === notif.id ? { ...n, read: true } : n))
            );
            if (notif.auctionId) {
              const target = auctions.find((a) => a.id === notif.auctionId);
              if (target) {
                setIsNotificationsOpen(false);
                if (target.status === 'completed') {
                  setAuditAuction(target);
                } else {
                  setSelectedAuction(target);
                }
              }
            }
          }}
        />
      )}

      {/* Auth Modal for Login / Registration */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
      />

      {/* Admin Panel Modal for mameboss98@gmail.com */}
      <AdminPanelModal
        isOpen={isAdminPanelOpen}
        onClose={() => setIsAdminPanelOpen(false)}
        adminEmail="mameboss98@gmail.com"
        auctions={auctions}
        onSaveAuction={handleSaveAuction}
        onDeleteAuction={handleDeleteAuction}
      />

      {/* Mobile Sticky Bottom Navigation Bar */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-md border-t border-slate-800 px-2 py-1.5 flex items-center justify-around shadow-2xl">
        <button
          onClick={() => {
            setActiveNavTab('auctions');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center gap-0.5 px-3 py-1 text-[11px] font-medium transition-colors ${
            activeNavTab === 'auctions' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>ጨረታዎች</span>
        </button>

        <button
          onClick={() => setIsWalletOpen(true)}
          className="flex flex-col items-center gap-0.5 px-3 py-1 text-[11px] font-medium text-slate-300 hover:text-amber-300 transition-colors"
        >
          <Wallet className="w-4 h-4 text-amber-400" />
          <span className="font-mono text-[10px] text-amber-300">{formatETB(activeUser.walletBalanceETB)}</span>
        </button>

        <button
          onClick={() => setIsMyBidsOpen(true)}
          className="flex flex-col items-center gap-0.5 px-3 py-1 text-[11px] font-medium text-slate-400 hover:text-slate-200 transition-colors relative"
        >
          <Trophy className="w-4 h-4 text-slate-400" />
          <span>ጨረታዎቼ</span>
          {activeUser.totalBidsPlaced > 0 && (
            <span className="absolute top-0.5 right-2 bg-amber-400 text-slate-950 text-[9px] font-bold rounded-full w-3.5 h-3.5 flex items-center justify-center">
              {activeUser.totalBidsPlaced}
            </span>
          )}
        </button>

        <button
          onClick={() => {
            if (currentUser) {
              if (isAdmin) {
                setIsAdminPanelOpen(true);
              } else {
                setIsWalletOpen(true);
              }
            } else {
              setIsAuthOpen(true);
            }
          }}
          className="flex flex-col items-center gap-0.5 px-3 py-1 text-[11px] font-medium text-amber-400 hover:text-amber-300 transition-colors"
        >
          <div className="w-5 h-5 rounded-full bg-amber-400/20 border border-amber-400/50 flex items-center justify-center text-amber-300">
            {currentUser ? (
              <span className="font-bold text-[9px]">{activeUser.name.charAt(0).toUpperCase()}</span>
            ) : (
              <User className="w-3 h-3 text-amber-400" />
            )}
          </div>
          <span>{currentUser ? (isAdmin ? 'አድሚን' : 'መለያዬ') : 'ተመዝገብ / ግባ'}</span>
        </button>
      </nav>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
